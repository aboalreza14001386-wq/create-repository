import 'package:flutter/material.dart';
import '../presentation/product_management_screen/product_management_screen.dart';
import '../presentation/business_profile_management_screen/business_profile_management_screen.dart';
import '../presentation/business_owner_dashboard_screen/business_owner_dashboard_screen.dart';
import '../presentation/write_review_screen/write_review_screen.dart';
import '../presentation/customer_search_screen/customer_search_screen.dart';
import '../presentation/business_profile_detail_screen/business_profile_detail_screen.dart';

class AppRoutes {
  // TODO: Add your routes here
  static const String initial = '/';
  static const String productManagement = '/product-management-screen';
  static const String businessProfileManagement =
      '/business-profile-management-screen';
  static const String businessOwnerDashboard =
      '/business-owner-dashboard-screen';
  static const String writeReview = '/write-review-screen';
  static const String customerSearch = '/customer-search-screen';
  static const String businessProfileDetail = '/business-profile-detail-screen';

  static Map<String, WidgetBuilder> routes = {
    initial: (context) => const ProductManagementScreen(),
    productManagement: (context) => const ProductManagementScreen(),
    businessProfileManagement: (context) =>
        const BusinessProfileManagementScreen(),
    businessOwnerDashboard: (context) => const BusinessOwnerDashboardScreen(),
    writeReview: (context) => const WriteReviewScreen(),
    customerSearch: (context) => const CustomerSearchScreen(),
    businessProfileDetail: (context) => const BusinessProfileDetailScreen(),
    // TODO: Add your other routes here
  };
}
