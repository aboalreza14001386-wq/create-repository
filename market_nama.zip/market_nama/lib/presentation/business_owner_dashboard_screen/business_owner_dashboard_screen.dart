import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:sizer/sizer.dart';

import '../../core/app_export.dart';
import './widgets/business_profile_summary_card.dart';
import './widgets/dashboard_metrics_card.dart';
import './widgets/quick_action_card.dart';
import './widgets/recent_products_section.dart';
import './widgets/recent_reviews_section.dart';

class BusinessOwnerDashboardScreen extends StatefulWidget {
  const BusinessOwnerDashboardScreen({Key? key}) : super(key: key);

  @override
  State<BusinessOwnerDashboardScreen> createState() =>
      _BusinessOwnerDashboardScreenState();
}

class _BusinessOwnerDashboardScreenState
    extends State<BusinessOwnerDashboardScreen> {
  bool _isBusinessVisible = true;
  bool _isLoading = false;

  // Mock business data
  final Map<String, dynamic> _businessData = {
    "id": 1,
    "name": "رستوران سنتی پارسیان",
    "nameEn": "Parsian Traditional Restaurant",
    "category": "رستوران",
    "categoryEn": "Restaurant",
    "address": "تهران، خیابان ولیعصر، پلاک ۱۲۳",
    "addressEn": "Tehran, Vali-e Asr Street, No. 123",
    "phone": "۰۲۱-۸۸۷۷۶۶۵۵",
    "phoneEn": "021-88776655",
    "description": "رستوران سنتی با غذاهای اصیل ایرانی و فضای دنج",
    "descriptionEn":
        "Traditional restaurant with authentic Iranian cuisine and cozy atmosphere",
    "image":
        "https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?fm=jpg&q=60&w=3000&ixlib=rb-4.0.3",
    "rating": 4.5,
    "totalReviews": 127,
    "isVisible": true,
    "hours": "۹:۰۰ - ۲۳:۰۰",
    "hoursEn": "9:00 AM - 11:00 PM"
  };

  // Mock products data
  final List<Map<String, dynamic>> _recentProducts = [
    {
      "id": 1,
      "name": "کباب کوبیده",
      "nameEn": "Koobideh Kebab",
      "price": "۲۵۰,۰۰۰ تومان",
      "priceEn": "250,000 IRR",
      "image":
          "https://images.unsplash.com/photo-1544025162-d76694265947?fm=jpg&q=60&w=3000&ixlib=rb-4.0.3",
      "description": "کباب کوبیده تازه با گوشت مرغوب",
      "descriptionEn": "Fresh koobideh kebab with premium meat"
    },
    {
      "id": 2,
      "name": "چلو خورشت قیمه",
      "nameEn": "Ghormeh Sabzi Stew",
      "price": "۱۸۰,۰۰۰ تومان",
      "priceEn": "180,000 IRR",
      "image":
          "https://images.unsplash.com/photo-1565299624946-b28f40a0ca4b?fm=jpg&q=60&w=3000&ixlib=rb-4.0.3",
      "description": "خورشت سنتی با سبزیجات تازه",
      "descriptionEn": "Traditional stew with fresh herbs"
    },
    {
      "id": 3,
      "name": "آش رشته",
      "nameEn": "Ash Reshteh",
      "price": "۱۲۰,۰۰۰ تومان",
      "priceEn": "120,000 IRR",
      "image":
          "https://images.unsplash.com/photo-1574484284002-952d92456975?fm=jpg&q=60&w=3000&ixlib=rb-4.0.3",
      "description": "آش سنتی با رشته و سبزیجات",
      "descriptionEn": "Traditional noodle soup with herbs"
    }
  ];

  // Mock reviews data
  final List<Map<String, dynamic>> _recentReviews = [
    {
      "id": 1,
      "customerName": "علی احمدی",
      "customerNameEn": "Ali Ahmadi",
      "customerAvatar":
          "https://cdn.pixabay.com/photo/2015/03/04/22/35/avatar-659652_640.png",
      "rating": 5,
      "comment": "غذا بسیار خوشمزه بود و سرویس عالی داشتند. حتماً دوباره میام.",
      "commentEn":
          "The food was delicious and the service was excellent. Will definitely come back.",
      "date": "۲ روز پیش",
      "dateEn": "2 days ago"
    },
    {
      "id": 2,
      "customerName": "فاطمه رضایی",
      "customerNameEn": "Fatemeh Rezaei",
      "customerAvatar":
          "https://cdn.pixabay.com/photo/2015/03/04/22/35/avatar-659652_640.png",
      "rating": 4,
      "comment": "فضای رستوران دنج و آرام بود. کباب کوبیده فوق‌العاده بود.",
      "commentEn":
          "The restaurant atmosphere was cozy and peaceful. The koobideh kebab was amazing.",
      "date": "۵ روز پیش",
      "dateEn": "5 days ago"
    },
    {
      "id": 3,
      "customerName": "محمد حسینی",
      "customerNameEn": "Mohammad Hosseini",
      "customerAvatar":
          "https://cdn.pixabay.com/photo/2015/03/04/22/35/avatar-659652_640.png",
      "rating": 5,
      "comment": "بهترین رستوران سنتی منطقه. کیفیت غذا و قیمت مناسب.",
      "commentEn":
          "Best traditional restaurant in the area. Great food quality and reasonable prices.",
      "date": "۱ هفته پیش",
      "dateEn": "1 week ago"
    }
  ];

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;

    return Scaffold(
      appBar: AppBar(
        title: Text(
          'داشبورد کسب‌وکار',
          style: Theme.of(context).textTheme.titleLarge?.copyWith(
                fontWeight: FontWeight.bold,
              ),
        ),
        centerTitle: true,
        leading: IconButton(
          icon: CustomIconWidget(
            iconName: 'arrow_back',
            color:
                isDark ? AppTheme.textPrimaryDark : AppTheme.textPrimaryLight,
            size: 24,
          ),
          onPressed: () => Navigator.pushReplacementNamed(
              context, '/customer-search-screen'),
        ),
        actions: [
          IconButton(
            icon: CustomIconWidget(
              iconName: 'menu',
              color:
                  isDark ? AppTheme.textPrimaryDark : AppTheme.textPrimaryLight,
              size: 24,
            ),
            onPressed: () => _showDrawer(context),
          ),
        ],
      ),
      body: RefreshIndicator(
        onRefresh: _refreshDashboard,
        child: SingleChildScrollView(
          physics: AlwaysScrollableScrollPhysics(),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Business Header with Visibility Toggle
              _buildBusinessHeader(),

              // Dashboard Metrics
              _buildDashboardMetrics(),

              // Quick Actions
              _buildQuickActions(),

              // Business Profile Summary
              BusinessProfileSummaryCard(
                businessData: _businessData,
                onEditPressed: () => Navigator.pushNamed(
                    context, '/business-profile-management-screen'),
              ),

              // Recent Products Section
              RecentProductsSection(
                products: _recentProducts,
                onAddProduct: () =>
                    Navigator.pushNamed(context, '/product-management-screen'),
                onProductTap: (product) => _showProductDetails(product),
              ),

              // Recent Reviews Section
              RecentReviewsSection(
                reviews: _recentReviews,
                onViewAllReviews: () =>
                    Navigator.pushNamed(context, '/write-review-screen'),
              ),

              SizedBox(height: 10.h),
            ],
          ),
        ),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () =>
            Navigator.pushNamed(context, '/product-management-screen'),
        child: CustomIconWidget(
          iconName: 'add',
          color: Colors.white,
          size: 24,
        ),
        tooltip: 'Add Product',
      ),
    );
  }

  Widget _buildBusinessHeader() {
    final isDark = Theme.of(context).brightness == Brightness.dark;

    return Container(
      margin: EdgeInsets.all(4.w),
      padding: EdgeInsets.all(4.w),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [
            isDark ? AppTheme.primaryDark : AppTheme.primaryLight,
            isDark ? AppTheme.primaryVariantDark : AppTheme.primaryVariantLight,
          ],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(16),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'خوش آمدید',
                      style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                            color: Colors.white.withValues(alpha: 0.9),
                          ),
                    ),
                    SizedBox(height: 0.5.h),
                    Text(
                      _businessData['name'] as String,
                      style: Theme.of(context).textTheme.titleLarge?.copyWith(
                            color: Colors.white,
                            fontWeight: FontWeight.bold,
                          ),
                      overflow: TextOverflow.ellipsis,
                      maxLines: 2,
                    ),
                  ],
                ),
              ),
              CustomIconWidget(
                iconName: 'store',
                color: Colors.white,
                size: 32,
              ),
            ],
          ),
          SizedBox(height: 3.h),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                'وضعیت نمایش کسب‌وکار',
                style: Theme.of(context).textTheme.titleMedium?.copyWith(
                      color: Colors.white,
                      fontWeight: FontWeight.w600,
                    ),
              ),
              Switch(
                value: _isBusinessVisible,
                onChanged: _toggleBusinessVisibility,
                activeColor:
                    isDark ? AppTheme.secondaryDark : AppTheme.secondaryLight,
                activeTrackColor:
                    (isDark ? AppTheme.secondaryDark : AppTheme.secondaryLight)
                        .withValues(alpha: 0.3),
              ),
            ],
          ),
          SizedBox(height: 1.h),
          Text(
            _isBusinessVisible
                ? 'کسب‌وکار شما برای مشتریان قابل مشاهده است'
                : 'کسب‌وکار شما مخفی است',
            style: Theme.of(context).textTheme.bodySmall?.copyWith(
                  color: Colors.white.withValues(alpha: 0.8),
                ),
          ),
        ],
      ),
    );
  }

  Widget _buildDashboardMetrics() {
    return Container(
      margin: EdgeInsets.symmetric(horizontal: 4.w, vertical: 2.h),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'آمار کلی',
            style: Theme.of(context).textTheme.titleLarge?.copyWith(
                  fontWeight: FontWeight.bold,
                ),
          ),
          SizedBox(height: 2.h),
          Row(
            children: [
              Expanded(
                child: DashboardMetricsCard(
                  title: 'تعداد محصولات',
                  value: '${_recentProducts.length}',
                  subtitle: 'محصول فعال',
                  iconName: 'inventory_2',
                ),
              ),
              Expanded(
                child: DashboardMetricsCard(
                  title: 'امتیاز میانگین',
                  value: '${_businessData['rating']}',
                  subtitle: 'از ۵ امتیاز',
                  iconName: 'star',
                ),
              ),
            ],
          ),
          Row(
            children: [
              Expanded(
                child: DashboardMetricsCard(
                  title: 'نظرات اخیر',
                  value: '${_recentReviews.length}',
                  subtitle: 'نظر جدید',
                  iconName: 'rate_review',
                ),
              ),
              Expanded(
                child: DashboardMetricsCard(
                  title: 'کل نظرات',
                  value: '${_businessData['totalReviews']}',
                  subtitle: 'نظر ثبت شده',
                  iconName: 'reviews',
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildQuickActions() {
    return Container(
      margin: EdgeInsets.symmetric(horizontal: 4.w, vertical: 2.h),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'دسترسی سریع',
            style: Theme.of(context).textTheme.titleLarge?.copyWith(
                  fontWeight: FontWeight.bold,
                ),
          ),
          SizedBox(height: 2.h),
          Row(
            children: [
              Expanded(
                child: QuickActionCard(
                  title: 'ویرایش پروفایل',
                  subtitle: 'اطلاعات کسب‌وکار',
                  iconName: 'edit',
                  onTap: () => Navigator.pushNamed(
                      context, '/business-profile-management-screen'),
                ),
              ),
              Expanded(
                child: QuickActionCard(
                  title: 'مدیریت محصولات',
                  subtitle: 'افزودن و ویرایش',
                  iconName: 'inventory',
                  onTap: () => Navigator.pushNamed(
                      context, '/product-management-screen'),
                ),
              ),
            ],
          ),
          Row(
            children: [
              Expanded(
                child: QuickActionCard(
                  title: 'مشاهده نظرات',
                  subtitle: 'نظرات مشتریان',
                  iconName: 'comment',
                  onTap: () =>
                      Navigator.pushNamed(context, '/write-review-screen'),
                ),
              ),
              Expanded(
                child: QuickActionCard(
                  title: 'آپلود تصاویر',
                  subtitle: 'گالری کسب‌وکار',
                  iconName: 'photo_camera',
                  onTap: () => _showImageUploadOptions(),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Future<void> _refreshDashboard() async {
    setState(() {
      _isLoading = true;
    });

    // Simulate API call
    await Future.delayed(Duration(seconds: 2));

    setState(() {
      _isLoading = false;
    });

    Fluttertoast.showToast(
      msg: "داده‌ها به‌روزرسانی شد",
      toastLength: Toast.LENGTH_SHORT,
      gravity: ToastGravity.BOTTOM,
      backgroundColor: AppTheme.getSuccessColor(
          Theme.of(context).brightness == Brightness.light),
      textColor: Colors.white,
    );
  }

  void _toggleBusinessVisibility(bool value) {
    setState(() {
      _isBusinessVisible = value;
      _businessData['isVisible'] = value;
    });

    Fluttertoast.showToast(
      msg:
          value ? "کسب‌وکار شما اکنون قابل مشاهده است" : "کسب‌وکار شما مخفی شد",
      toastLength: Toast.LENGTH_SHORT,
      gravity: ToastGravity.BOTTOM,
      backgroundColor: value
          ? AppTheme.getSuccessColor(
              Theme.of(context).brightness == Brightness.light)
          : AppTheme.getWarningColor(
              Theme.of(context).brightness == Brightness.light),
      textColor: Colors.white,
    );
  }

  void _showProductDetails(Map<String, dynamic> product) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (context) => Container(
        padding: EdgeInsets.all(4.w),
        height: 50.h,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Center(
              child: Container(
                width: 12.w,
                height: 0.5.h,
                decoration: BoxDecoration(
                  color: Colors.grey[300],
                  borderRadius: BorderRadius.circular(10),
                ),
              ),
            ),
            SizedBox(height: 3.h),
            ClipRRect(
              borderRadius: BorderRadius.circular(12),
              child: CustomImageWidget(
                imageUrl: product['image'] as String,
                width: double.infinity,
                height: 25.h,
                fit: BoxFit.cover,
              ),
            ),
            SizedBox(height: 2.h),
            Text(
              product['name'] as String,
              style: Theme.of(context).textTheme.titleLarge?.copyWith(
                    fontWeight: FontWeight.bold,
                  ),
            ),
            SizedBox(height: 1.h),
            Text(
              product['price'] as String,
              style: Theme.of(context).textTheme.titleMedium?.copyWith(
                    color: AppTheme.secondaryLight,
                    fontWeight: FontWeight.bold,
                  ),
            ),
            SizedBox(height: 2.h),
            Text(
              product['description'] as String,
              style: Theme.of(context).textTheme.bodyMedium,
            ),
          ],
        ),
      ),
    );
  }

  void _showImageUploadOptions() {
    showModalBottomSheet(
      context: context,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (context) => Container(
        padding: EdgeInsets.all(4.w),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Center(
              child: Container(
                width: 12.w,
                height: 0.5.h,
                decoration: BoxDecoration(
                  color: Colors.grey[300],
                  borderRadius: BorderRadius.circular(10),
                ),
              ),
            ),
            SizedBox(height: 3.h),
            Text(
              'آپلود تصویر',
              style: Theme.of(context).textTheme.titleLarge?.copyWith(
                    fontWeight: FontWeight.bold,
                  ),
            ),
            SizedBox(height: 3.h),
            ListTile(
              leading: CustomIconWidget(
                iconName: 'photo_camera',
                color: AppTheme.primaryLight,
                size: 24,
              ),
              title: Text('دوربین'),
              onTap: () {
                Navigator.pop(context);
                Fluttertoast.showToast(
                  msg: "دوربین باز شد",
                  toastLength: Toast.LENGTH_SHORT,
                  gravity: ToastGravity.BOTTOM,
                );
              },
            ),
            ListTile(
              leading: CustomIconWidget(
                iconName: 'photo_library',
                color: AppTheme.primaryLight,
                size: 24,
              ),
              title: Text('گالری'),
              onTap: () {
                Navigator.pop(context);
                Fluttertoast.showToast(
                  msg: "گالری باز شد",
                  toastLength: Toast.LENGTH_SHORT,
                  gravity: ToastGravity.BOTTOM,
                );
              },
            ),
            SizedBox(height: 2.h),
          ],
        ),
      ),
    );
  }

  void _showDrawer(BuildContext context) {
    showModalBottomSheet(
      context: context,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (context) => Container(
        padding: EdgeInsets.all(4.w),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Center(
              child: Container(
                width: 12.w,
                height: 0.5.h,
                decoration: BoxDecoration(
                  color: Colors.grey[300],
                  borderRadius: BorderRadius.circular(10),
                ),
              ),
            ),
            SizedBox(height: 3.h),
            Text(
              'منو',
              style: Theme.of(context).textTheme.titleLarge?.copyWith(
                    fontWeight: FontWeight.bold,
                  ),
            ),
            SizedBox(height: 3.h),
            ListTile(
              leading: CustomIconWidget(
                iconName: 'settings',
                color: AppTheme.primaryLight,
                size: 24,
              ),
              title: Text('تنظیمات'),
              onTap: () {
                Navigator.pop(context);
                Fluttertoast.showToast(
                  msg: "تنظیمات",
                  toastLength: Toast.LENGTH_SHORT,
                  gravity: ToastGravity.BOTTOM,
                );
              },
            ),
            ListTile(
              leading: CustomIconWidget(
                iconName: 'help',
                color: AppTheme.primaryLight,
                size: 24,
              ),
              title: Text('راهنما'),
              onTap: () {
                Navigator.pop(context);
                Fluttertoast.showToast(
                  msg: "راهنما",
                  toastLength: Toast.LENGTH_SHORT,
                  gravity: ToastGravity.BOTTOM,
                );
              },
            ),
            ListTile(
              leading: CustomIconWidget(
                iconName: 'logout',
                color: AppTheme.errorLight,
                size: 24,
              ),
              title: Text(
                'خروج',
                style: TextStyle(color: AppTheme.errorLight),
              ),
              onTap: () {
                Navigator.pop(context);
                Navigator.pushReplacementNamed(
                    context, '/customer-search-screen');
              },
            ),
            SizedBox(height: 2.h),
          ],
        ),
      ),
    );
  }
}
