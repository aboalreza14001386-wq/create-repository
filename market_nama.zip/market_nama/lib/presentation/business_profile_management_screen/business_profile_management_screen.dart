import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:image_picker/image_picker.dart';
import 'package:sizer/sizer.dart';

import '../../core/app_export.dart';
import './widgets/business_details_section.dart';
import './widgets/business_hours_section.dart';
import './widgets/category_selection_bottom_sheet.dart';
import './widgets/contact_information_section.dart';
import './widgets/media_upload_section.dart';

class BusinessProfileManagementScreen extends StatefulWidget {
  const BusinessProfileManagementScreen({Key? key}) : super(key: key);

  @override
  State<BusinessProfileManagementScreen> createState() =>
      _BusinessProfileManagementScreenState();
}

class _BusinessProfileManagementScreenState
    extends State<BusinessProfileManagementScreen> {
  final _formKey = GlobalKey<FormState>();
  final _scrollController = ScrollController();

  // Controllers
  final _nameController = TextEditingController();
  final _descriptionController = TextEditingController();
  final _addressController = TextEditingController();
  final _phoneController = TextEditingController();

  // Form state
  String? _selectedCategory;
  XFile? _selectedImage;
  bool _isLoading = false;
  bool _isDraftSaved = false;

  // Error states
  String? _nameError;
  String? _descriptionError;
  String? _categoryError;
  String? _addressError;
  String? _phoneError;
  String? _imageError;

  // Business hours
  Map<String, Map<String, dynamic>> _businessHours = {
    'saturday': {
      'isOpen': true,
      'openTime': const TimeOfDay(hour: 9, minute: 0),
      'closeTime': const TimeOfDay(hour: 18, minute: 0)
    },
    'sunday': {
      'isOpen': true,
      'openTime': const TimeOfDay(hour: 9, minute: 0),
      'closeTime': const TimeOfDay(hour: 18, minute: 0)
    },
    'monday': {
      'isOpen': true,
      'openTime': const TimeOfDay(hour: 9, minute: 0),
      'closeTime': const TimeOfDay(hour: 18, minute: 0)
    },
    'tuesday': {
      'isOpen': true,
      'openTime': const TimeOfDay(hour: 9, minute: 0),
      'closeTime': const TimeOfDay(hour: 18, minute: 0)
    },
    'wednesday': {
      'isOpen': true,
      'openTime': const TimeOfDay(hour: 9, minute: 0),
      'closeTime': const TimeOfDay(hour: 18, minute: 0)
    },
    'thursday': {
      'isOpen': true,
      'openTime': const TimeOfDay(hour: 9, minute: 0),
      'closeTime': const TimeOfDay(hour: 18, minute: 0)
    },
    'friday': {'isOpen': false, 'openTime': null, 'closeTime': null},
  };

  // Mock business data for editing
  final Map<String, dynamic> _mockBusinessData = {
    "id": 1,
    "name": "رستوران سنتی کوهستان",
    "category": "رستوران",
    "description":
        "رستوران سنتی با غذاهای محلی و فضای دنج. بهترین کباب و خورش‌های سنتی را در محیطی آرام و دلنشین تجربه کنید.",
    "address": "تهران، خیابان ولیعصر، نرسیده به میدان ونک، پلاک ۱۲۳",
    "phone": "09123456789",
    "image":
        "https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?fm=jpg&q=60&w=3000&ixlib=rb-4.0.3",
    "rating": 4.5,
    "reviewCount": 127,
    "isOpen": true,
    "businessHours": {
      "saturday": {"isOpen": true, "openTime": "09:00", "closeTime": "22:00"},
      "sunday": {"isOpen": true, "openTime": "09:00", "closeTime": "22:00"},
      "monday": {"isOpen": true, "openTime": "09:00", "closeTime": "22:00"},
      "tuesday": {"isOpen": true, "openTime": "09:00", "closeTime": "22:00"},
      "wednesday": {"isOpen": true, "openTime": "09:00", "closeTime": "22:00"},
      "thursday": {"isOpen": true, "openTime": "09:00", "closeTime": "22:00"},
      "friday": {"isOpen": false, "openTime": null, "closeTime": null},
    }
  };

  @override
  void initState() {
    super.initState();
    _loadBusinessData();
    _saveDraftPeriodically();
  }

  @override
  void dispose() {
    _nameController.dispose();
    _descriptionController.dispose();
    _addressController.dispose();
    _phoneController.dispose();
    _scrollController.dispose();
    super.dispose();
  }

  void _loadBusinessData() {
    // Load existing business data for editing
    _nameController.text = _mockBusinessData['name'] ?? '';
    _descriptionController.text = _mockBusinessData['description'] ?? '';
    _addressController.text = _mockBusinessData['address'] ?? '';
    _phoneController.text = _mockBusinessData['phone'] ?? '';
    _selectedCategory = _mockBusinessData['category'];

    // Load business hours
    final hours = _mockBusinessData['businessHours'] as Map<String, dynamic>?;
    if (hours != null) {
      hours.forEach((day, data) {
        final dayData = data as Map<String, dynamic>;
        _businessHours[day] = {
          'isOpen': dayData['isOpen'] ?? false,
          'openTime': dayData['openTime'] != null
              ? _parseTimeString(dayData['openTime'])
              : null,
          'closeTime': dayData['closeTime'] != null
              ? _parseTimeString(dayData['closeTime'])
              : null,
        };
      });
    }
  }

  TimeOfDay? _parseTimeString(String timeString) {
    try {
      final parts = timeString.split(':');
      return TimeOfDay(
        hour: int.parse(parts[0]),
        minute: int.parse(parts[1]),
      );
    } catch (e) {
      return null;
    }
  }

  void _saveDraftPeriodically() {
    // Save draft every 30 seconds
    Future.delayed(const Duration(seconds: 30), () {
      if (mounted && !_isDraftSaved) {
        _saveDraft();
        _saveDraftPeriodically();
      }
    });
  }

  void _saveDraft() {
    // Save current form data as draft
    _isDraftSaved = true;
    // In a real app, this would save to local storage or backend
  }

  void _clearErrors() {
    setState(() {
      _nameError = null;
      _descriptionError = null;
      _categoryError = null;
      _addressError = null;
      _phoneError = null;
      _imageError = null;
    });
  }

  bool _validateForm() {
    _clearErrors();
    bool isValid = true;

    // Validate business name
    if (_nameController.text.trim().isEmpty) {
      _nameError = 'نام کسب و کار الزامی است';
      isValid = false;
    } else if (_nameController.text.trim().length < 2) {
      _nameError = 'نام کسب و کار باید حداقل ۲ کاراکتر باشد';
      isValid = false;
    }

    // Validate category
    if (_selectedCategory == null || _selectedCategory!.isEmpty) {
      _categoryError = 'انتخاب دسته‌بندی الزامی است';
      isValid = false;
    }

    // Validate address
    if (_addressController.text.trim().isEmpty) {
      _addressError = 'آدرس الزامی است';
      isValid = false;
    } else if (_addressController.text.trim().length < 10) {
      _addressError = 'آدرس باید حداقل ۱۰ کاراکتر باشد';
      isValid = false;
    }

    // Validate phone number
    if (_phoneController.text.trim().isEmpty) {
      _phoneError = 'شماره تماس الزامی است';
      isValid = false;
    } else if (!_isValidIranianPhoneNumber(_phoneController.text.trim())) {
      _phoneError = 'شماره تماس معتبر نیست';
      isValid = false;
    }

    // Validate business hours
    bool hasOpenDay = _businessHours.values.any((day) => day['isOpen'] == true);
    if (!hasOpenDay) {
      _showErrorDialog('حداقل یک روز در هفته باید باز باشید');
      isValid = false;
    }

    setState(() {});
    return isValid;
  }

  bool _isValidIranianPhoneNumber(String phone) {
    // Iranian mobile number validation
    final RegExp phoneRegex = RegExp(r'^09[0-9]{9}$');
    return phoneRegex.hasMatch(phone);
  }

  void _showCategoryBottomSheet() {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (context) => CategorySelectionBottomSheet(
        selectedCategory: _selectedCategory,
        onCategorySelected: (category) {
          setState(() {
            _selectedCategory = category;
            _categoryError = null;
          });
        },
      ),
    );
  }

  void _onHoursChanged(String day, TimeOfDay? openTime, TimeOfDay? closeTime) {
    setState(() {
      _businessHours[day] = {
        'isOpen': _businessHours[day]!['isOpen'],
        'openTime': openTime,
        'closeTime': closeTime,
      };
    });
  }

  void _onDayToggle(String day, bool isOpen) {
    setState(() {
      _businessHours[day] = {
        'isOpen': isOpen,
        'openTime': isOpen
            ? (_businessHours[day]!['openTime'] ??
                const TimeOfDay(hour: 9, minute: 0))
            : null,
        'closeTime': isOpen
            ? (_businessHours[day]!['closeTime'] ??
                const TimeOfDay(hour: 18, minute: 0))
            : null,
      };
    });
  }

  void _onImageSelected(XFile? image) {
    setState(() {
      _selectedImage = image;
      _imageError = null;
    });
  }

  void _showErrorDialog(String message) {
    final theme = Theme.of(context);

    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text(
          'خطا',
          style: theme.textTheme.titleMedium,
          textDirection: TextDirection.rtl,
        ),
        content: Text(
          message,
          style: theme.textTheme.bodyMedium,
          textDirection: TextDirection.rtl,
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text(
              'باشه',
              textDirection: TextDirection.rtl,
            ),
          ),
        ],
      ),
    );
  }

  void _showSuccessDialog() {
    final theme = Theme.of(context);

    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) => AlertDialog(
        title: Text(
          'موفقیت',
          style: theme.textTheme.titleMedium,
          textDirection: TextDirection.rtl,
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            CustomIconWidget(
              iconName: 'check_circle',
              color: AppTheme.getSuccessColor(
                  theme.brightness == Brightness.light),
              size: 48,
            ),
            SizedBox(height: 2.h),
            Text(
              'پروفایل کسب و کار شما با موفقیت ذخیره شد',
              style: theme.textTheme.bodyMedium,
              textDirection: TextDirection.rtl,
              textAlign: TextAlign.center,
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.pop(context);
              // Redirect to customer search view as per requirements
              Navigator.pushReplacementNamed(
                  context, '/customer-search-screen');
            },
            child: Text(
              'ادامه',
              textDirection: TextDirection.rtl,
            ),
          ),
        ],
      ),
    );
  }

  Future<void> _saveProfile() async {
    if (!_validateForm()) {
      // Scroll to first error
      _scrollController.animateTo(
        0,
        duration: const Duration(milliseconds: 300),
        curve: Curves.easeInOut,
      );
      return;
    }

    setState(() => _isLoading = true);

    try {
      // Simulate API call
      await Future.delayed(const Duration(seconds: 2));

      // Show success toast in Farsi
      Fluttertoast.showToast(
        msg: "پروفایل با موفقیت ذخیره شد",
        toastLength: Toast.LENGTH_LONG,
        gravity: ToastGravity.BOTTOM,
        backgroundColor: AppTheme.getSuccessColor(
            Theme.of(context).brightness == Brightness.light),
        textColor: Colors.white,
        fontSize: 14.sp,
      );

      // Show success dialog and redirect
      _showSuccessDialog();
    } catch (e) {
      _showErrorDialog('خطا در ذخیره اطلاعات. لطفاً دوباره تلاش کنید.');
    } finally {
      setState(() => _isLoading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        backgroundColor: theme.scaffoldBackgroundColor,
        appBar: AppBar(
          title: Text(
            'مدیریت پروفایل کسب و کار',
            style: theme.appBarTheme.titleTextStyle,
          ),
          leading: IconButton(
            onPressed: () => Navigator.pop(context),
            icon: CustomIconWidget(
              iconName: 'arrow_back',
              color: theme.appBarTheme.iconTheme?.color ??
                  theme.colorScheme.onSurface,
              size: 24,
            ),
          ),
          actions: [
            if (_isDraftSaved)
              Padding(
                padding: EdgeInsets.only(left: 4.w),
                child: Center(
                  child: Text(
                    'پیش‌نویس ذخیره شد',
                    style: theme.textTheme.bodySmall?.copyWith(
                      color: AppTheme.getSuccessColor(
                          theme.brightness == Brightness.light),
                    ),
                  ),
                ),
              ),
          ],
        ),
        body: Form(
          key: _formKey,
          child: Column(
            children: [
              Expanded(
                child: SingleChildScrollView(
                  controller: _scrollController,
                  padding: EdgeInsets.only(bottom: 12.h),
                  child: Column(
                    children: [
                      SizedBox(height: 2.h),

                      // Business Details Section
                      BusinessDetailsSection(
                        nameController: _nameController,
                        descriptionController: _descriptionController,
                        selectedCategory: _selectedCategory,
                        onCategoryTap: _showCategoryBottomSheet,
                        nameError: _nameError,
                        descriptionError: _descriptionError,
                        categoryError: _categoryError,
                      ),

                      // Contact Information Section
                      ContactInformationSection(
                        addressController: _addressController,
                        phoneController: _phoneController,
                        addressError: _addressError,
                        phoneError: _phoneError,
                      ),

                      // Business Hours Section
                      BusinessHoursSection(
                        businessHours: _businessHours,
                        onHoursChanged: _onHoursChanged,
                        onDayToggle: _onDayToggle,
                      ),

                      // Media Upload Section
                      MediaUploadSection(
                        selectedImage: _selectedImage,
                        onImageSelected: _onImageSelected,
                        imageError: _imageError,
                      ),

                      SizedBox(height: 4.h),
                    ],
                  ),
                ),
              ),

              // Fixed Save Button
              Container(
                padding: EdgeInsets.all(4.w),
                decoration: BoxDecoration(
                  color: theme.scaffoldBackgroundColor,
                  boxShadow: [
                    BoxShadow(
                      color: theme.shadowColor.withValues(alpha: 0.1),
                      blurRadius: 8,
                      offset: const Offset(0, -2),
                    ),
                  ],
                ),
                child: SafeArea(
                  child: SizedBox(
                    width: double.infinity,
                    height: 6.h,
                    child: ElevatedButton(
                      onPressed: _isLoading ? null : _saveProfile,
                      style: ElevatedButton.styleFrom(
                        backgroundColor: AppTheme.primaryLight,
                        foregroundColor: AppTheme.onPrimaryLight,
                        disabledBackgroundColor: theme
                            .colorScheme.onSurfaceVariant
                            .withValues(alpha: 0.3),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12),
                        ),
                      ),
                      child: _isLoading
                          ? Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                SizedBox(
                                  width: 20,
                                  height: 20,
                                  child: CircularProgressIndicator(
                                    strokeWidth: 2,
                                    valueColor: AlwaysStoppedAnimation<Color>(
                                      AppTheme.onPrimaryLight,
                                    ),
                                  ),
                                ),
                                SizedBox(width: 3.w),
                                Text(
                                  'در حال ذخیره...',
                                  style: theme.textTheme.labelLarge?.copyWith(
                                    color: AppTheme.onPrimaryLight,
                                  ),
                                ),
                              ],
                            )
                          : Text(
                              'ذخیره پروفایل',
                              style: theme.textTheme.labelLarge?.copyWith(
                                color: AppTheme.onPrimaryLight,
                                fontWeight: FontWeight.w600,
                              ),
                            ),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
