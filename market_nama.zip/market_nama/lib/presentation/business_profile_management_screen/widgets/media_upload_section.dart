import 'dart:io';

import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';

class MediaUploadSection extends StatefulWidget {
  final XFile? selectedImage;
  final Function(XFile?) onImageSelected;
  final String? imageError;

  const MediaUploadSection({
    Key? key,
    required this.selectedImage,
    required this.onImageSelected,
    this.imageError,
  }) : super(key: key);

  @override
  State<MediaUploadSection> createState() => _MediaUploadSectionState();
}

class _MediaUploadSectionState extends State<MediaUploadSection> {
  final ImagePicker _picker = ImagePicker();
  bool _isLoading = false;

  Future<bool> _requestPermission() async {
    if (kIsWeb) return true;

    final status = await Permission.camera.request();
    return status.isGranted;
  }

  Future<void> _showImageSourceDialog() async {
    final theme = Theme.of(context);

    showModalBottomSheet(
      context: context,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (context) => Container(
        padding: EdgeInsets.all(4.w),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 12.w,
              height: 0.5.h,
              decoration: BoxDecoration(
                color: theme.colorScheme.onSurfaceVariant,
                borderRadius: BorderRadius.circular(2),
              ),
            ),
            SizedBox(height: 3.h),
            Text(
              'انتخاب تصویر',
              style: theme.textTheme.titleMedium?.copyWith(
                fontWeight: FontWeight.w600,
              ),
              textDirection: TextDirection.rtl,
            ),
            SizedBox(height: 3.h),
            ListTile(
              leading: CustomIconWidget(
                iconName: 'camera_alt',
                color: theme.colorScheme.primary,
                size: 24,
              ),
              title: Text(
                'دوربین',
                style: theme.textTheme.bodyLarge,
                textDirection: TextDirection.rtl,
              ),
              onTap: () {
                Navigator.pop(context);
                _pickImage(ImageSource.camera);
              },
            ),
            ListTile(
              leading: CustomIconWidget(
                iconName: 'photo_library',
                color: theme.colorScheme.primary,
                size: 24,
              ),
              title: Text(
                'گالری',
                style: theme.textTheme.bodyLarge,
                textDirection: TextDirection.rtl,
              ),
              onTap: () {
                Navigator.pop(context);
                _pickImage(ImageSource.gallery);
              },
            ),
            if (widget.selectedImage != null)
              ListTile(
                leading: CustomIconWidget(
                  iconName: 'delete',
                  color: theme.colorScheme.error,
                  size: 24,
                ),
                title: Text(
                  'حذف تصویر',
                  style: theme.textTheme.bodyLarge?.copyWith(
                    color: theme.colorScheme.error,
                  ),
                  textDirection: TextDirection.rtl,
                ),
                onTap: () {
                  Navigator.pop(context);
                  widget.onImageSelected(null);
                },
              ),
            SizedBox(height: 2.h),
          ],
        ),
      ),
    );
  }

  Future<void> _pickImage(ImageSource source) async {
    if (!await _requestPermission()) {
      _showPermissionDeniedDialog();
      return;
    }

    setState(() => _isLoading = true);

    try {
      final XFile? image = await _picker.pickImage(
        source: source,
        maxWidth: 1024,
        maxHeight: 1024,
        imageQuality: 85,
      );

      if (image != null) {
        widget.onImageSelected(image);
      }
    } catch (e) {
      _showErrorDialog('خطا در انتخاب تصویر. لطفاً دوباره تلاش کنید.');
    } finally {
      setState(() => _isLoading = false);
    }
  }

  void _showPermissionDeniedDialog() {
    final theme = Theme.of(context);

    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text(
          'مجوز دسترسی',
          style: theme.textTheme.titleMedium,
          textDirection: TextDirection.rtl,
        ),
        content: Text(
          'برای انتخاب تصویر، دسترسی به دوربین و گالری مورد نیاز است.',
          style: theme.textTheme.bodyMedium,
          textDirection: TextDirection.rtl,
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text(
              'باشه',
              textDirection: TextDirection.rtl,
            ),
          ),
          TextButton(
            onPressed: () {
              Navigator.pop(context);
              openAppSettings();
            },
            child: Text(
              'تنظیمات',
              textDirection: TextDirection.rtl,
            ),
          ),
        ],
      ),
    );
  }

  void _showErrorDialog(String message) {
    final theme = Theme.of(context);

    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text(
          'خطا',
          style: theme.textTheme.titleMedium,
          textDirection: TextDirection.rtl,
        ),
        content: Text(
          message,
          style: theme.textTheme.bodyMedium,
          textDirection: TextDirection.rtl,
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text(
              'باشه',
              textDirection: TextDirection.rtl,
            ),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final isLight = theme.brightness == Brightness.light;

    return Container(
      padding: EdgeInsets.all(4.w),
      margin: EdgeInsets.symmetric(horizontal: 4.w, vertical: 2.h),
      decoration: BoxDecoration(
        color: theme.cardColor,
        borderRadius: BorderRadius.circular(12),
        boxShadow: [
          BoxShadow(
            color: isLight ? AppTheme.shadowLight : AppTheme.shadowDark,
            blurRadius: 8,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'تصویر کسب و کار',
            style: theme.textTheme.titleMedium?.copyWith(
              fontWeight: FontWeight.w600,
            ),
            textDirection: TextDirection.rtl,
          ),
          SizedBox(height: 3.h),

          // Image Upload Area
          InkWell(
            onTap: _isLoading ? null : _showImageSourceDialog,
            child: Container(
              width: double.infinity,
              height: 25.h,
              decoration: BoxDecoration(
                color: theme.colorScheme.surface.withValues(alpha: 0.5),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(
                  color: widget.imageError != null
                      ? theme.colorScheme.error
                      : theme.colorScheme.outline.withValues(alpha: 0.3),
                ),
              ),
              child: _isLoading
                  ? Center(
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          CircularProgressIndicator(
                            color: theme.colorScheme.primary,
                          ),
                          SizedBox(height: 2.h),
                          Text(
                            'در حال بارگذاری...',
                            style: theme.textTheme.bodyMedium,
                            textDirection: TextDirection.rtl,
                          ),
                        ],
                      ),
                    )
                  : widget.selectedImage != null
                      ? Stack(
                          children: [
                            ClipRRect(
                              borderRadius: BorderRadius.circular(12),
                              child: kIsWeb
                                  ? Image.network(
                                      widget.selectedImage!.path,
                                      width: double.infinity,
                                      height: double.infinity,
                                      fit: BoxFit.cover,
                                      errorBuilder:
                                          (context, error, stackTrace) {
                                        return _buildPlaceholder();
                                      },
                                    )
                                  : Image.file(
                                      File(widget.selectedImage!.path),
                                      width: double.infinity,
                                      height: double.infinity,
                                      fit: BoxFit.cover,
                                      errorBuilder:
                                          (context, error, stackTrace) {
                                        return _buildPlaceholder();
                                      },
                                    ),
                            ),
                            Positioned(
                              top: 2.w,
                              right: 2.w,
                              child: Container(
                                decoration: BoxDecoration(
                                  color: theme.colorScheme.surface
                                      .withValues(alpha: 0.9),
                                  borderRadius: BorderRadius.circular(20),
                                ),
                                child: IconButton(
                                  onPressed: () => _showImageSourceDialog(),
                                  icon: CustomIconWidget(
                                    iconName: 'edit',
                                    color: theme.colorScheme.primary,
                                    size: 20,
                                  ),
                                ),
                              ),
                            ),
                          ],
                        )
                      : _buildPlaceholder(),
            ),
          ),

          if (widget.imageError != null) ...[
            SizedBox(height: 1.h),
            Text(
              widget.imageError!,
              style: theme.textTheme.bodySmall?.copyWith(
                color: theme.colorScheme.error,
              ),
              textDirection: TextDirection.rtl,
            ),
          ],

          SizedBox(height: 2.h),
          Text(
            'تصویر اصلی کسب و کار خود را انتخاب کنید. این تصویر در نتایج جستجو نمایش داده می‌شود.',
            style: theme.textTheme.bodySmall?.copyWith(
              color: theme.colorScheme.onSurfaceVariant,
            ),
            textDirection: TextDirection.rtl,
          ),
        ],
      ),
    );
  }

  Widget _buildPlaceholder() {
    final theme = Theme.of(context);

    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        CustomIconWidget(
          iconName: 'add_a_photo',
          color: theme.colorScheme.primary,
          size: 48,
        ),
        SizedBox(height: 2.h),
        Text(
          'انتخاب تصویر',
          style: theme.textTheme.bodyLarge?.copyWith(
            fontWeight: FontWeight.w500,
          ),
          textDirection: TextDirection.rtl,
        ),
        SizedBox(height: 1.h),
        Text(
          'از دوربین یا گالری',
          style: theme.textTheme.bodySmall?.copyWith(
            color: theme.colorScheme.onSurfaceVariant,
          ),
          textDirection: TextDirection.rtl,
        ),
      ],
    );
  }
}