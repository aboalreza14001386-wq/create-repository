import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';

class BusinessHoursSection extends StatelessWidget {
  final Map<String, Map<String, dynamic>> businessHours;
  final Function(String day, TimeOfDay? openTime, TimeOfDay? closeTime)
      onHoursChanged;
  final Function(String day, bool isOpen) onDayToggle;

  const BusinessHoursSection({
    Key? key,
    required this.businessHours,
    required this.onHoursChanged,
    required this.onDayToggle,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final isLight = theme.brightness == Brightness.light;

    final List<Map<String, String>> weekDays = [
      {'key': 'saturday', 'name': 'شنبه'},
      {'key': 'sunday', 'name': 'یکشنبه'},
      {'key': 'monday', 'name': 'دوشنبه'},
      {'key': 'tuesday', 'name': 'سه‌شنبه'},
      {'key': 'wednesday', 'name': 'چهارشنبه'},
      {'key': 'thursday', 'name': 'پنج‌شنبه'},
      {'key': 'friday', 'name': 'جمعه'},
    ];

    return Container(
      padding: EdgeInsets.all(4.w),
      margin: EdgeInsets.symmetric(horizontal: 4.w, vertical: 2.h),
      decoration: BoxDecoration(
        color: theme.cardColor,
        borderRadius: BorderRadius.circular(12),
        boxShadow: [
          BoxShadow(
            color: isLight ? AppTheme.shadowLight : AppTheme.shadowDark,
            blurRadius: 8,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'ساعات کاری',
            style: theme.textTheme.titleMedium?.copyWith(
              fontWeight: FontWeight.w600,
            ),
            textDirection: TextDirection.rtl,
          ),
          SizedBox(height: 3.h),
          ...weekDays
              .map((day) => _buildDayRow(context, day['key']!, day['name']!)),
        ],
      ),
    );
  }

  Widget _buildDayRow(BuildContext context, String dayKey, String dayName) {
    final theme = Theme.of(context);
    final dayData = businessHours[dayKey] ??
        {'isOpen': false, 'openTime': null, 'closeTime': null};
    final bool isOpen = dayData['isOpen'] ?? false;
    final TimeOfDay? openTime = dayData['openTime'];
    final TimeOfDay? closeTime = dayData['closeTime'];

    return Container(
      margin: EdgeInsets.only(bottom: 2.h),
      padding: EdgeInsets.all(3.w),
      decoration: BoxDecoration(
        color: theme.colorScheme.surface.withValues(alpha: 0.5),
        borderRadius: BorderRadius.circular(8),
        border: Border.all(
          color: theme.colorScheme.outline.withValues(alpha: 0.3),
        ),
      ),
      child: Column(
        children: [
          Row(
            children: [
              Switch(
                value: isOpen,
                onChanged: (value) => onDayToggle(dayKey, value),
              ),
              SizedBox(width: 3.w),
              Expanded(
                child: Text(
                  dayName,
                  style: theme.textTheme.bodyLarge?.copyWith(
                    fontWeight: FontWeight.w500,
                    color: isOpen
                        ? theme.colorScheme.onSurface
                        : theme.colorScheme.onSurfaceVariant,
                  ),
                  textDirection: TextDirection.rtl,
                ),
              ),
              if (!isOpen)
                Text(
                  'تعطیل',
                  style: theme.textTheme.bodyMedium?.copyWith(
                    color: theme.colorScheme.error,
                    fontWeight: FontWeight.w500,
                  ),
                  textDirection: TextDirection.rtl,
                ),
            ],
          ),
          if (isOpen) ...[
            SizedBox(height: 2.h),
            Row(
              children: [
                Expanded(
                  child: _buildTimeSelector(
                    context,
                    'ساعت باز شدن',
                    openTime,
                    (time) => onHoursChanged(dayKey, time, closeTime),
                  ),
                ),
                SizedBox(width: 4.w),
                Expanded(
                  child: _buildTimeSelector(
                    context,
                    'ساعت بسته شدن',
                    closeTime,
                    (time) => onHoursChanged(dayKey, openTime, time),
                  ),
                ),
              ],
            ),
          ],
        ],
      ),
    );
  }

  Widget _buildTimeSelector(
    BuildContext context,
    String label,
    TimeOfDay? selectedTime,
    Function(TimeOfDay?) onTimeSelected,
  ) {
    final theme = Theme.of(context);

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          label,
          style: theme.textTheme.bodySmall?.copyWith(
            fontWeight: FontWeight.w500,
          ),
          textDirection: TextDirection.rtl,
        ),
        SizedBox(height: 1.h),
        InkWell(
          onTap: () async {
            final TimeOfDay? time = await showTimePicker(
              context: context,
              initialTime: selectedTime ?? const TimeOfDay(hour: 9, minute: 0),
              builder: (context, child) {
                return Directionality(
                  textDirection: TextDirection.rtl,
                  child: child!,
                );
              },
            );
            if (time != null) {
              onTimeSelected(time);
            }
          },
          child: Container(
            width: double.infinity,
            padding: EdgeInsets.symmetric(horizontal: 3.w, vertical: 3.w),
            decoration: BoxDecoration(
              border: Border.all(color: theme.colorScheme.outline),
              borderRadius: BorderRadius.circular(8),
              color: theme.inputDecorationTheme.fillColor,
            ),
            child: Row(
              children: [
                CustomIconWidget(
                  iconName: 'access_time',
                  color: theme.colorScheme.primary,
                  size: 16,
                ),
                SizedBox(width: 2.w),
                Expanded(
                  child: Text(
                    selectedTime != null
                        ? '${selectedTime.hour.toString().padLeft(2, '0')}:${selectedTime.minute.toString().padLeft(2, '0')}'
                        : 'انتخاب کنید',
                    style: theme.textTheme.bodyMedium?.copyWith(
                      color: selectedTime != null
                          ? theme.colorScheme.onSurface
                          : theme.colorScheme.onSurfaceVariant,
                    ),
                    textDirection: TextDirection.ltr,
                  ),
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }
}
