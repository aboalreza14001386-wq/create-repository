import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';
import '../../../widgets/custom_icon_widget.dart';

class CategorySelectionBottomSheet extends StatefulWidget {
  final String? selectedCategory;
  final Function(String) onCategorySelected;

  const CategorySelectionBottomSheet({
    Key? key,
    required this.selectedCategory,
    required this.onCategorySelected,
  }) : super(key: key);

  @override
  State<CategorySelectionBottomSheet> createState() =>
      _CategorySelectionBottomSheetState();
}

class _CategorySelectionBottomSheetState
    extends State<CategorySelectionBottomSheet> {
  final TextEditingController _searchController = TextEditingController();
  List<Map<String, dynamic>> _filteredCategories = [];

  final List<Map<String, dynamic>> _businessCategories = [
    {
      'name': 'رستوران',
      'icon': 'restaurant',
      'description': 'غذاخوری و رستوران'
    },
    {'name': 'کافه', 'icon': 'local_cafe', 'description': 'کافه و قهوه خانه'},
    {'name': 'فروشگاه', 'icon': 'store', 'description': 'فروشگاه عمومی'},
    {
      'name': 'سوپرمارکت',
      'icon': 'local_grocery_store',
      'description': 'سوپرمارکت و خواربار'
    },
    {
      'name': 'داروخانه',
      'icon': 'local_pharmacy',
      'description': 'داروخانه و درمان'
    },
    {
      'name': 'بیمارستان',
      'icon': 'local_hospital',
      'description': 'بیمارستان و درمانگاه'
    },
    {'name': 'مدرسه', 'icon': 'school', 'description': 'مدرسه و آموزشگاه'},
    {
      'name': 'بانک',
      'icon': 'account_balance',
      'description': 'بانک و مؤسسات مالی'
    },
    {'name': 'هتل', 'icon': 'hotel', 'description': 'هتل و اقامتگاه'},
    {
      'name': 'آرایشگاه',
      'icon': 'content_cut',
      'description': 'آرایشگاه و زیبایی'
    },
    {
      'name': 'ورزشگاه',
      'icon': 'fitness_center',
      'description': 'باشگاه ورزشی'
    },
    {
      'name': 'کتابخانه',
      'icon': 'local_library',
      'description': 'کتابخانه و مطالعه'
    },
    {'name': 'پارک', 'icon': 'park', 'description': 'پارک و تفریحات'},
    {'name': 'سینما', 'icon': 'local_movies', 'description': 'سینما و سرگرمی'},
    {
      'name': 'پمپ بنزین',
      'icon': 'local_gas_station',
      'description': 'پمپ بنزین و سوخت'
    },
    {'name': 'تاکسی', 'icon': 'local_taxi', 'description': 'تاکسی و حمل و نقل'},
    {'name': 'پست', 'icon': 'local_post_office', 'description': 'اداره پست'},
    {'name': 'پلیس', 'icon': 'local_police', 'description': 'کلانتری و پلیس'},
    {
      'name': 'آتش نشانی',
      'icon': 'local_fire_department',
      'description': 'آتش نشانی'
    },
    {
      'name': 'خدمات فنی',
      'icon': 'build',
      'description': 'تعمیرات و خدمات فنی'
    },
    {'name': 'املاک', 'icon': 'home', 'description': 'مشاور املاک'},
    {'name': 'حقوقی', 'icon': 'gavel', 'description': 'دفتر وکالت و حقوقی'},
    {'name': 'پزشکی', 'icon': 'medical_services', 'description': 'مطب پزشک'},
    {
      'name': 'دندانپزشکی',
      'icon': 'medical_services',
      'description': 'مطب دندانپزشک'
    },
    {
      'name': 'لوازم خانگی',
      'icon': 'home_repair_service',
      'description': 'فروش لوازم خانگی'
    },
    {
      'name': 'موبایل',
      'icon': 'phone_android',
      'description': 'فروش و تعمیر موبایل'
    },
    {
      'name': 'کامپیوتر',
      'icon': 'computer',
      'description': 'فروش و تعمیر کامپیوتر'
    },
    {'name': 'خیاطی', 'icon': 'content_cut', 'description': 'خیاطی و دوخت'},
    {'name': 'کفش', 'icon': 'shopping_bag', 'description': 'فروش کفش'},
    {'name': 'لباس', 'icon': 'checkroom', 'description': 'فروش پوشاک'},
  ];

  @override
  void initState() {
    super.initState();
    _filteredCategories = List.from(_businessCategories);
    _searchController.addListener(_filterCategories);
  }

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  void _filterCategories() {
    final query = _searchController.text.toLowerCase();
    setState(() {
      _filteredCategories = _businessCategories.where((category) {
        final name = (category['name'] as String).toLowerCase();
        final description = (category['description'] as String).toLowerCase();
        return name.contains(query) || description.contains(query);
      }).toList();
    });
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Container(
      height: 80.h,
      padding: EdgeInsets.all(4.w),
      child: Column(
        children: [
          // Handle bar
          Container(
            width: 12.w,
            height: 0.5.h,
            decoration: BoxDecoration(
              color: theme.colorScheme.onSurfaceVariant,
              borderRadius: BorderRadius.circular(2),
            ),
          ),
          SizedBox(height: 3.h),

          // Title
          Text(
            'انتخاب دسته‌بندی',
            style: theme.textTheme.titleLarge?.copyWith(
              fontWeight: FontWeight.w600,
            ),
            textDirection: TextDirection.rtl,
          ),
          SizedBox(height: 3.h),

          // Search field
          TextField(
            controller: _searchController,
            textDirection: TextDirection.rtl,
            decoration: InputDecoration(
              hintText: 'جستجو در دسته‌بندی‌ها...',
              hintTextDirection: TextDirection.rtl,
              prefixIcon: Padding(
                padding: EdgeInsets.all(3.w),
                child: CustomIconWidget(
                  iconName: 'search',
                  color: theme.colorScheme.onSurfaceVariant,
                  size: 20,
                ),
              ),
              suffixIcon: _searchController.text.isNotEmpty
                  ? IconButton(
                      onPressed: () {
                        _searchController.clear();
                      },
                      icon: CustomIconWidget(
                        iconName: 'clear',
                        color: theme.colorScheme.onSurfaceVariant,
                        size: 20,
                      ),
                    )
                  : null,
            ),
          ),
          SizedBox(height: 3.h),

          // Categories list
          Expanded(
            child: _filteredCategories.isEmpty
                ? Center(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        CustomIconWidget(
                          iconName: 'search_off',
                          color: theme.colorScheme.onSurfaceVariant,
                          size: 48,
                        ),
                        SizedBox(height: 2.h),
                        Text(
                          'دسته‌بندی یافت نشد',
                          style: theme.textTheme.bodyLarge?.copyWith(
                            color: theme.colorScheme.onSurfaceVariant,
                          ),
                          textDirection: TextDirection.rtl,
                        ),
                      ],
                    ),
                  )
                : ListView.builder(
                    itemCount: _filteredCategories.length,
                    itemBuilder: (context, index) {
                      final category = _filteredCategories[index];
                      final isSelected =
                          widget.selectedCategory == category['name'];

                      return Container(
                        margin: EdgeInsets.only(bottom: 1.h),
                        child: ListTile(
                          leading: Container(
                            padding: EdgeInsets.all(2.w),
                            decoration: BoxDecoration(
                              color: isSelected
                                  ? theme.colorScheme.primary
                                      .withValues(alpha: 0.1)
                                  : theme.colorScheme.surface,
                              borderRadius: BorderRadius.circular(8),
                            ),
                            child: CustomIconWidget(
                              iconName: category['icon'],
                              color: isSelected
                                  ? theme.colorScheme.primary
                                  : theme.colorScheme.onSurfaceVariant,
                              size: 24,
                            ),
                          ),
                          title: Text(
                            category['name'],
                            style: theme.textTheme.bodyLarge?.copyWith(
                              fontWeight: isSelected
                                  ? FontWeight.w600
                                  : FontWeight.w400,
                              color: isSelected
                                  ? theme.colorScheme.primary
                                  : theme.colorScheme.onSurface,
                            ),
                            textDirection: TextDirection.rtl,
                          ),
                          subtitle: Text(
                            category['description'],
                            style: theme.textTheme.bodySmall?.copyWith(
                              color: theme.colorScheme.onSurfaceVariant,
                            ),
                            textDirection: TextDirection.rtl,
                          ),
                          trailing: isSelected
                              ? CustomIconWidget(
                                  iconName: 'check_circle',
                                  color: theme.colorScheme.primary,
                                  size: 24,
                                )
                              : null,
                          onTap: () {
                            widget.onCategorySelected(category['name']);
                            Navigator.pop(context);
                          },
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(12),
                          ),
                          tileColor: isSelected
                              ? theme.colorScheme.primary
                                  .withValues(alpha: 0.05)
                              : null,
                        ),
                      );
                    },
                  ),
          ),
        ],
      ),
    );
  }
}
