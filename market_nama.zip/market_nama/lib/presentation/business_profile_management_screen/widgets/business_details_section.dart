import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';

class BusinessDetailsSection extends StatelessWidget {
  final TextEditingController nameController;
  final TextEditingController descriptionController;
  final String? selectedCategory;
  final VoidCallback onCategoryTap;
  final String? nameError;
  final String? descriptionError;
  final String? categoryError;

  const BusinessDetailsSection({
    Key? key,
    required this.nameController,
    required this.descriptionController,
    required this.selectedCategory,
    required this.onCategoryTap,
    this.nameError,
    this.descriptionError,
    this.categoryError,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final isLight = theme.brightness == Brightness.light;

    return Container(
      padding: EdgeInsets.all(4.w),
      margin: EdgeInsets.symmetric(horizontal: 4.w, vertical: 2.h),
      decoration: BoxDecoration(
        color: theme.cardColor,
        borderRadius: BorderRadius.circular(12),
        boxShadow: [
          BoxShadow(
            color: isLight ? AppTheme.shadowLight : AppTheme.shadowDark,
            blurRadius: 8,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'اطلاعات کسب و کار',
            style: theme.textTheme.titleMedium?.copyWith(
              fontWeight: FontWeight.w600,
            ),
            textDirection: TextDirection.rtl,
          ),
          SizedBox(height: 3.h),

          // Business Name Field
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'نام کسب و کار *',
                style: theme.textTheme.bodyMedium?.copyWith(
                  fontWeight: FontWeight.w500,
                ),
                textDirection: TextDirection.rtl,
              ),
              SizedBox(height: 1.h),
              TextFormField(
                controller: nameController,
                textDirection: TextDirection.rtl,
                decoration: InputDecoration(
                  hintText: 'نام کسب و کار خود را وارد کنید',
                  hintTextDirection: TextDirection.rtl,
                  errorText: nameError,
                  prefixIcon: Padding(
                    padding: EdgeInsets.all(3.w),
                    child: CustomIconWidget(
                      iconName: 'business',
                      color: theme.colorScheme.primary,
                      size: 20,
                    ),
                  ),
                ),
                maxLength: 100,
                buildCounter: (context,
                    {required currentLength, required isFocused, maxLength}) {
                  return Text(
                    '$currentLength/${maxLength ?? 0}',
                    style: theme.textTheme.bodySmall,
                    textDirection: TextDirection.ltr,
                  );
                },
              ),
            ],
          ),

          SizedBox(height: 2.h),

          // Category Selection
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'دسته‌بندی *',
                style: theme.textTheme.bodyMedium?.copyWith(
                  fontWeight: FontWeight.w500,
                ),
                textDirection: TextDirection.rtl,
              ),
              SizedBox(height: 1.h),
              InkWell(
                onTap: onCategoryTap,
                child: Container(
                  width: double.infinity,
                  padding: EdgeInsets.symmetric(horizontal: 4.w, vertical: 4.w),
                  decoration: BoxDecoration(
                    border: Border.all(
                      color: categoryError != null
                          ? theme.colorScheme.error
                          : theme.colorScheme.outline,
                    ),
                    borderRadius: BorderRadius.circular(12),
                    color: theme.inputDecorationTheme.fillColor,
                  ),
                  child: Row(
                    children: [
                      CustomIconWidget(
                        iconName: 'keyboard_arrow_down',
                        color: theme.colorScheme.onSurfaceVariant,
                        size: 24,
                      ),
                      SizedBox(width: 3.w),
                      Expanded(
                        child: Text(
                          selectedCategory ??
                              'دسته‌بندی کسب و کار را انتخاب کنید',
                          style: theme.textTheme.bodyLarge?.copyWith(
                            color: selectedCategory != null
                                ? theme.colorScheme.onSurface
                                : theme.colorScheme.onSurfaceVariant,
                          ),
                          textDirection: TextDirection.rtl,
                        ),
                      ),
                      CustomIconWidget(
                        iconName: 'category',
                        color: theme.colorScheme.primary,
                        size: 20,
                      ),
                    ],
                  ),
                ),
              ),
              if (categoryError != null)
                Padding(
                  padding: EdgeInsets.only(top: 1.h, right: 4.w),
                  child: Text(
                    categoryError!,
                    style: theme.textTheme.bodySmall?.copyWith(
                      color: theme.colorScheme.error,
                    ),
                    textDirection: TextDirection.rtl,
                  ),
                ),
            ],
          ),

          SizedBox(height: 2.h),

          // Description Field
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'توضیحات',
                style: theme.textTheme.bodyMedium?.copyWith(
                  fontWeight: FontWeight.w500,
                ),
                textDirection: TextDirection.rtl,
              ),
              SizedBox(height: 1.h),
              TextFormField(
                controller: descriptionController,
                textDirection: TextDirection.rtl,
                maxLines: 4,
                decoration: InputDecoration(
                  hintText: 'توضیحات کسب و کار خود را وارد کنید',
                  hintTextDirection: TextDirection.rtl,
                  errorText: descriptionError,
                  alignLabelWithHint: true,
                ),
                maxLength: 500,
                buildCounter: (context,
                    {required currentLength, required isFocused, maxLength}) {
                  return Text(
                    '$currentLength/${maxLength ?? 0}',
                    style: theme.textTheme.bodySmall,
                    textDirection: TextDirection.ltr,
                  );
                },
              ),
            ],
          ),
        ],
      ),
    );
  }
}
