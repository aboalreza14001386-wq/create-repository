import 'package:fl_chart/fl_chart.dart';
import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';
import '../../../theme/app_theme.dart';
import '../../../widgets/custom_icon_widget.dart';

class ReviewsSectionWidget extends StatelessWidget {
  final List<Map<String, dynamic>> reviews;
  final double averageRating;
  final int totalReviews;

  const ReviewsSectionWidget({
    Key? key,
    required this.reviews,
    required this.averageRating,
    required this.totalReviews,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final bool isDark = Theme.of(context).brightness == Brightness.dark;

    return Container(
      width: double.infinity,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.end,
        children: [
          // Section Header
          Row(
            mainAxisAlignment: MainAxisAlignment.end,
            children: [
              Text(
                'نظرات مشتریان',
                style: Theme.of(context).textTheme.titleLarge?.copyWith(
                      fontWeight: FontWeight.w700,
                      color: isDark
                          ? AppTheme.textPrimaryDark
                          : AppTheme.textPrimaryLight,
                    ),
                textDirection: TextDirection.rtl,
              ),
              SizedBox(width: 2.w),
              CustomIconWidget(
                iconName: 'rate_review',
                color: isDark ? AppTheme.primaryDark : AppTheme.primaryLight,
                size: 24,
              ),
            ],
          ),

          SizedBox(height: 2.h),

          // Rating Overview
          Container(
            width: double.infinity,
            padding: EdgeInsets.all(4.w),
            decoration: BoxDecoration(
              color: isDark ? AppTheme.cardDark : AppTheme.cardLight,
              borderRadius: BorderRadius.circular(12),
              border: Border.all(
                color: isDark ? AppTheme.dividerDark : AppTheme.dividerLight,
                width: 1,
              ),
            ),
            child: Row(
              children: [
                // Rating Distribution Chart
                Expanded(
                  flex: 2,
                  child: Container(
                    height: 15.h,
                    child: _buildRatingChart(isDark),
                  ),
                ),

                SizedBox(width: 4.w),

                // Rating Summary
                Expanded(
                  flex: 3,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.end,
                    children: [
                      // Average Rating
                      Row(
                        mainAxisAlignment: MainAxisAlignment.end,
                        children: [
                          Text(
                            _convertToPersianNumbers(
                                averageRating.toStringAsFixed(1)),
                            style: Theme.of(context)
                                .textTheme
                                .headlineMedium
                                ?.copyWith(
                                  fontWeight: FontWeight.w700,
                                  color: isDark
                                      ? AppTheme.textPrimaryDark
                                      : AppTheme.textPrimaryLight,
                                ),
                            textDirection: TextDirection.rtl,
                          ),
                          SizedBox(width: 2.w),
                          CustomIconWidget(
                            iconName: 'star',
                            color: AppTheme.warningLight,
                            size: 32,
                          ),
                        ],
                      ),

                      SizedBox(height: 0.5.h),

                      // Total Reviews
                      Text(
                        'از ${_convertToPersianNumbers(totalReviews.toString())} نظر',
                        style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                              color: isDark
                                  ? AppTheme.textSecondaryDark
                                  : AppTheme.textSecondaryLight,
                            ),
                        textDirection: TextDirection.rtl,
                      ),

                      SizedBox(height: 1.h),

                      // Star Distribution
                      ..._buildStarDistribution(isDark),
                    ],
                  ),
                ),
              ],
            ),
          ),

          SizedBox(height: 2.h),

          // Individual Reviews
          ...reviews
              .map((review) => _buildReviewCard(context, review, isDark))
              .toList(),
        ],
      ),
    );
  }

  Widget _buildRatingChart(bool isDark) {
    final ratingCounts = _calculateRatingDistribution();

    return BarChart(
      BarChartData(
        alignment: BarChartAlignment.spaceAround,
        maxY:
            ratingCounts.values.reduce((a, b) => a > b ? a : b).toDouble() + 1,
        barTouchData: BarTouchData(enabled: false),
        titlesData: FlTitlesData(
          show: true,
          bottomTitles: AxisTitles(
            sideTitles: SideTitles(
              showTitles: true,
              getTitlesWidget: (value, meta) {
                return Text(
                  _convertToPersianNumbers('${value.toInt()}'),
                  style: TextStyle(
                    color: isDark
                        ? AppTheme.textSecondaryDark
                        : AppTheme.textSecondaryLight,
                    fontSize: 10.sp,
                  ),
                );
              },
            ),
          ),
          leftTitles: AxisTitles(sideTitles: SideTitles(showTitles: false)),
          topTitles: AxisTitles(sideTitles: SideTitles(showTitles: false)),
          rightTitles: AxisTitles(sideTitles: SideTitles(showTitles: false)),
        ),
        gridData: FlGridData(show: false),
        borderData: FlBorderData(show: false),
        barGroups: ratingCounts.entries.map((entry) {
          return BarChartGroupData(
            x: entry.key,
            barRods: [
              BarChartRodData(
                toY: entry.value.toDouble(),
                color: isDark ? AppTheme.primaryDark : AppTheme.primaryLight,
                width: 3.w,
                borderRadius: BorderRadius.circular(2),
              ),
            ],
          );
        }).toList(),
      ),
    );
  }

  List<Widget> _buildStarDistribution(bool isDark) {
    final ratingCounts = _calculateRatingDistribution();

    return List.generate(5, (index) {
      final starCount = 5 - index;
      final count = ratingCounts[starCount] ?? 0;
      final percentage = totalReviews > 0 ? (count / totalReviews) : 0.0;

      return Padding(
        padding: EdgeInsets.symmetric(vertical: 0.2.h),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.end,
          children: [
            Text(
              _convertToPersianNumbers(count.toString()),
              style: TextStyle(
                    color: isDark
                        ? AppTheme.textSecondaryDark
                        : AppTheme.textSecondaryLight,
                  ),
            ),
            SizedBox(width: 2.w),
            Expanded(
              child: Container(
                height: 0.5.h,
                decoration: BoxDecoration(
                  color: isDark ? AppTheme.dividerDark : AppTheme.dividerLight,
                  borderRadius: BorderRadius.circular(2),
                ),
                child: FractionallySizedBox(
                  alignment: Alignment.centerRight,
                  widthFactor: percentage,
                  child: Container(
                    decoration: BoxDecoration(
                      color: AppTheme.warningLight,
                      borderRadius: BorderRadius.circular(2),
                    ),
                  ),
                ),
              ),
            ),
            SizedBox(width: 2.w),
            Text(
              _convertToPersianNumbers(starCount.toString()),
              style: TextStyle(
                    color: isDark
                        ? AppTheme.textSecondaryDark
                        : AppTheme.textSecondaryLight,
                  ),
            ),
            SizedBox(width: 1.w),
            CustomIconWidget(
              iconName: 'star',
              color: AppTheme.warningLight,
              size: 12,
            ),
          ],
        ),
      );
    });
  }

  Widget _buildReviewCard(
      BuildContext context, Map<String, dynamic> review, bool isDark) {
    return Container(
      width: double.infinity,
      margin: EdgeInsets.only(bottom: 2.h),
      padding: EdgeInsets.all(4.w),
      decoration: BoxDecoration(
        color: isDark ? AppTheme.cardDark : AppTheme.cardLight,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: isDark ? AppTheme.dividerDark : AppTheme.dividerLight,
          width: 1,
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.end,
        children: [
          // Review Header
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                _formatDate(review['date']),
                style: Theme.of(context).textTheme.bodySmall?.copyWith(
                      color: isDark
                          ? AppTheme.textSecondaryDark
                          : AppTheme.textSecondaryLight,
                    ),
                textDirection: TextDirection.rtl,
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.end,
                children: [
                  Text(
                    review['customerName'] ?? 'مشتری',
                    style: Theme.of(context).textTheme.titleMedium?.copyWith(
                          fontWeight: FontWeight.w600,
                          color: isDark
                              ? AppTheme.textPrimaryDark
                              : AppTheme.textPrimaryLight,
                        ),
                    textDirection: TextDirection.rtl,
                  ),
                  SizedBox(width: 2.w),
                  CircleAvatar(
                    radius: 2.h,
                    backgroundColor:
                        isDark ? AppTheme.primaryDark : AppTheme.primaryLight,
                    child: Text(
                      (review['customerName'] ?? 'م')[0],
                      style: TextStyle(
                        color: AppTheme.onPrimaryLight,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ),
                ],
              ),
            ],
          ),

          SizedBox(height: 1.h),

          // Rating Stars
          Row(
            mainAxisAlignment: MainAxisAlignment.end,
            children: List.generate(5, (index) {
              return CustomIconWidget(
                iconName:
                    index < (review['rating'] ?? 0) ? 'star' : 'star_border',
                color: AppTheme.warningLight,
                size: 16,
              );
            }),
          ),

          SizedBox(height: 1.h),

          // Review Comment
          if (review['comment'] != null &&
              (review['comment'] as String).isNotEmpty)
            Text(
              review['comment'] as String,
              style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                    color: isDark
                        ? AppTheme.textPrimaryDark
                        : AppTheme.textPrimaryLight,
                    height: 1.4,
                  ),
              textAlign: TextAlign.right,
              textDirection: TextDirection.rtl,
            ),
        ],
      ),
    );
  }

  Map<int, int> _calculateRatingDistribution() {
    Map<int, int> distribution = {1: 0, 2: 0, 3: 0, 4: 0, 5: 0};

    for (var review in reviews) {
      int rating = review['rating'] ?? 0;
      if (rating >= 1 && rating <= 5) {
        distribution[rating] = (distribution[rating] ?? 0) + 1;
      }
    }

    return distribution;
  }

  String _formatDate(dynamic date) {
    if (date == null) return '';

    DateTime dateTime;
    if (date is String) {
      dateTime = DateTime.tryParse(date) ?? DateTime.now();
    } else if (date is DateTime) {
      dateTime = date;
    } else {
      return '';
    }

    final now = DateTime.now();
    final difference = now.difference(dateTime);

    if (difference.inDays == 0) {
      return 'امروز';
    } else if (difference.inDays == 1) {
      return 'دیروز';
    } else if (difference.inDays < 30) {
      return '${_convertToPersianNumbers(difference.inDays.toString())} روز پیش';
    } else {
      return '${_convertToPersianNumbers(dateTime.day.toString())}/${_convertToPersianNumbers(dateTime.month.toString())}/${_convertToPersianNumbers(dateTime.year.toString())}';
    }
  }

  String _convertToPersianNumbers(String input) {
    const english = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9'];
    const persian = ['۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹'];

    String result = input;
    for (int i = 0; i < english.length; i++) {
      result = result.replaceAll(english[i], persian[i]);
    }
    return result;
  }
}