import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';

class ContactActionsWidget extends StatelessWidget {
  final Map<String, dynamic> businessData;

  const ContactActionsWidget({
    Key? key,
    required this.businessData,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final bool isDark = Theme.of(context).brightness == Brightness.dark;

    return Container(
      width: double.infinity,
      child: Row(
        children: [
          // Call Button
          Expanded(
            child: Container(
              height: 6.h,
              child: ElevatedButton.icon(
                onPressed: () => _makePhoneCall(context),
                icon: CustomIconWidget(
                  iconName: 'phone',
                  color: AppTheme.onSecondaryLight,
                  size: 20,
                ),
                label: Text(
                  'تماس',
                  style: Theme.of(context).textTheme.titleMedium?.copyWith(
                        color: AppTheme.onSecondaryLight,
                        fontWeight: FontWeight.w600,
                      ),
                  textDirection: TextDirection.rtl,
                ),
                style: ElevatedButton.styleFrom(
                  backgroundColor:
                      isDark ? AppTheme.secondaryDark : AppTheme.secondaryLight,
                  foregroundColor: AppTheme.onSecondaryLight,
                  elevation: 2,
                  shadowColor:
                      isDark ? AppTheme.shadowDark : AppTheme.shadowLight,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                ),
              ),
            ),
          ),

          SizedBox(width: 3.w),

          // Directions Button
          Expanded(
            child: Container(
              height: 6.h,
              child: OutlinedButton.icon(
                onPressed: () => _openDirections(context),
                icon: CustomIconWidget(
                  iconName: 'directions',
                  color:
                      isDark ? AppTheme.secondaryDark : AppTheme.secondaryLight,
                  size: 20,
                ),
                label: Text(
                  'مسیریابی',
                  style: Theme.of(context).textTheme.titleMedium?.copyWith(
                        color: isDark
                            ? AppTheme.secondaryDark
                            : AppTheme.secondaryLight,
                        fontWeight: FontWeight.w600,
                      ),
                  textDirection: TextDirection.rtl,
                ),
                style: OutlinedButton.styleFrom(
                  side: BorderSide(
                    color: isDark
                        ? AppTheme.secondaryDark
                        : AppTheme.secondaryLight,
                    width: 2,
                  ),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  void _makePhoneCall(BuildContext context) {
    // Show confirmation dialog
    showDialog(
      context: context,
      builder: (BuildContext context) {
        final bool isDark = Theme.of(context).brightness == Brightness.dark;
        return Directionality(
          textDirection: TextDirection.rtl,
          child: AlertDialog(
            backgroundColor:
                isDark ? AppTheme.dialogDark : AppTheme.dialogLight,
            title: Text(
              'تماس با کسب و کار',
              style: Theme.of(context).textTheme.titleLarge?.copyWith(
                    color: isDark
                        ? AppTheme.textPrimaryDark
                        : AppTheme.textPrimaryLight,
                  ),
            ),
            content: Text(
              'آیا می‌خواهید با شماره ${_convertToPersianNumbers(businessData['phone'] ?? '۰۹۱۲۳۴۵۶۷۸۹')} تماس بگیرید؟',
              style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                    color: isDark
                        ? AppTheme.textSecondaryDark
                        : AppTheme.textSecondaryLight,
                  ),
            ),
            actions: [
              TextButton(
                onPressed: () => Navigator.of(context).pop(),
                child: Text(
                  'انصراف',
                  style: TextStyle(
                    color: isDark
                        ? AppTheme.textSecondaryDark
                        : AppTheme.textSecondaryLight,
                  ),
                ),
              ),
              ElevatedButton(
                onPressed: () {
                  Navigator.of(context).pop();
                  // In a real app, this would use url_launcher to make the call
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(
                      content: Text(
                        'در حال برقراری تماس...',
                        textDirection: TextDirection.rtl,
                      ),
                      backgroundColor:
                          isDark ? AppTheme.successDark : AppTheme.successLight,
                    ),
                  );
                },
                style: ElevatedButton.styleFrom(
                  backgroundColor:
                      isDark ? AppTheme.secondaryDark : AppTheme.secondaryLight,
                ),
                child: Text(
                  'تماس',
                  style: TextStyle(color: AppTheme.onSecondaryLight),
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  void _openDirections(BuildContext context) {
    // Show directions placeholder
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          'مسیریابی به زودی فعال خواهد شد',
          textDirection: TextDirection.rtl,
        ),
        backgroundColor: Theme.of(context).brightness == Brightness.dark
            ? AppTheme.warningDark
            : AppTheme.warningLight,
      ),
    );
  }

  String _convertToPersianNumbers(String input) {
    const english = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9'];
    const persian = ['۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹'];

    String result = input;
    for (int i = 0; i < english.length; i++) {
      result = result.replaceAll(english[i], persian[i]);
    }
    return result;
  }
}
