import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';

class BusinessHeaderWidget extends StatelessWidget {
  final Map<String, dynamic> businessData;

  const BusinessHeaderWidget({
    Key? key,
    required this.businessData,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final bool isDark = Theme.of(context).brightness == Brightness.dark;

    return Container(
      width: double.infinity,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Business Hero Image
          Container(
            width: double.infinity,
            height: 25.h,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(12),
              color: isDark ? AppTheme.cardDark : AppTheme.cardLight,
            ),
            child: ClipRRect(
              borderRadius: BorderRadius.circular(12),
              child: CustomImageWidget(
                imageUrl: businessData['heroImage'] ?? '',
                width: double.infinity,
                height: 25.h,
                fit: BoxFit.cover,
              ),
            ),
          ),

          SizedBox(height: 2.h),

          // Business Name
          Text(
            businessData['name'] ?? 'نام کسب و کار',
            style: Theme.of(context).textTheme.titleLarge?.copyWith(
                  fontWeight: FontWeight.w700,
                  color: isDark
                      ? AppTheme.textPrimaryDark
                      : AppTheme.textPrimaryLight,
                ),
            textAlign: TextAlign.right,
            textDirection: TextDirection.rtl,
          ),

          SizedBox(height: 1.h),

          // Category
          Container(
            padding: EdgeInsets.symmetric(horizontal: 3.w, vertical: 0.5.h),
            decoration: BoxDecoration(
              color: (isDark ? AppTheme.primaryDark : AppTheme.primaryLight)
                  .withValues(alpha: 0.1),
              borderRadius: BorderRadius.circular(20),
            ),
            child: Text(
              businessData['category'] ?? 'دسته‌بندی',
              style: Theme.of(context).textTheme.bodySmall?.copyWith(
                    color:
                        isDark ? AppTheme.primaryDark : AppTheme.primaryLight,
                    fontWeight: FontWeight.w500,
                  ),
              textAlign: TextAlign.right,
              textDirection: TextDirection.rtl,
            ),
          ),

          SizedBox(height: 1.5.h),

          // Rating Display
          Row(
            mainAxisAlignment: MainAxisAlignment.end,
            children: [
              Text(
                '(${businessData['reviewCount'] ?? 0} نظر)',
                style: Theme.of(context).textTheme.bodySmall?.copyWith(
                      color: isDark
                          ? AppTheme.textSecondaryDark
                          : AppTheme.textSecondaryLight,
                    ),
                textDirection: TextDirection.rtl,
              ),
              SizedBox(width: 2.w),
              Text(
                _convertToPersianNumbers(
                    (businessData['rating'] ?? 0.0).toStringAsFixed(1)),
                style: Theme.of(context).textTheme.titleMedium?.copyWith(
                      fontWeight: FontWeight.w600,
                      color: isDark
                          ? AppTheme.textPrimaryDark
                          : AppTheme.textPrimaryLight,
                    ),
                textDirection: TextDirection.rtl,
              ),
              SizedBox(width: 1.w),
              ...List.generate(5, (index) {
                return CustomIconWidget(
                  iconName: index < (businessData['rating'] ?? 0.0).floor()
                      ? 'star'
                      : 'star_border',
                  color: AppTheme.warningLight,
                  size: 18,
                );
              }),
            ],
          ),

          SizedBox(height: 2.h),

          // Address
          Row(
            mainAxisAlignment: MainAxisAlignment.end,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Expanded(
                child: Text(
                  businessData['address'] ?? 'آدرس کسب و کار',
                  style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                        color: isDark
                            ? AppTheme.textSecondaryDark
                            : AppTheme.textSecondaryLight,
                        height: 1.4,
                      ),
                  textAlign: TextAlign.right,
                  textDirection: TextDirection.rtl,
                ),
              ),
              SizedBox(width: 2.w),
              CustomIconWidget(
                iconName: 'location_on',
                color: isDark
                    ? AppTheme.textSecondaryDark
                    : AppTheme.textSecondaryLight,
                size: 20,
              ),
            ],
          ),

          SizedBox(height: 1.5.h),

          // Phone
          Row(
            mainAxisAlignment: MainAxisAlignment.end,
            children: [
              Text(
                _convertToPersianNumbers(
                    businessData['phone'] ?? '۰۹۱۲۳۴۵۶۷۸۹'),
                style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                      color: isDark
                          ? AppTheme.textSecondaryDark
                          : AppTheme.textSecondaryLight,
                    ),
                textDirection: TextDirection.rtl,
              ),
              SizedBox(width: 2.w),
              CustomIconWidget(
                iconName: 'phone',
                color: isDark
                    ? AppTheme.textSecondaryDark
                    : AppTheme.textSecondaryLight,
                size: 20,
              ),
            ],
          ),
        ],
      ),
    );
  }

  String _convertToPersianNumbers(String input) {
    const english = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9'];
    const persian = ['۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹'];

    String result = input;
    for (int i = 0; i < english.length; i++) {
      result = result.replaceAll(english[i], persian[i]);
    }
    return result;
  }
}
