import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';

class BusinessHoursWidget extends StatefulWidget {
  final Map<String, dynamic> businessData;

  const BusinessHoursWidget({
    Key? key,
    required this.businessData,
  }) : super(key: key);

  @override
  State<BusinessHoursWidget> createState() => _BusinessHoursWidgetState();
}

class _BusinessHoursWidgetState extends State<BusinessHoursWidget> {
  bool _isExpanded = false;

  @override
  Widget build(BuildContext context) {
    final bool isDark = Theme.of(context).brightness == Brightness.dark;
    final bool isOpen = widget.businessData['isOpen'] ?? true;

    return Container(
      width: double.infinity,
      padding: EdgeInsets.all(4.w),
      decoration: BoxDecoration(
        color: isDark ? AppTheme.cardDark : AppTheme.cardLight,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: isDark ? AppTheme.dividerDark : AppTheme.dividerLight,
          width: 1,
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.end,
        children: [
          // Header with current status
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              GestureDetector(
                onTap: () {
                  setState(() {
                    _isExpanded = !_isExpanded;
                  });
                },
                child: CustomIconWidget(
                  iconName:
                      _isExpanded ? 'keyboard_arrow_up' : 'keyboard_arrow_down',
                  color: isDark
                      ? AppTheme.textSecondaryDark
                      : AppTheme.textSecondaryLight,
                  size: 24,
                ),
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.end,
                children: [
                  Text(
                    isOpen ? 'باز' : 'بسته',
                    style: Theme.of(context).textTheme.titleMedium?.copyWith(
                          color: isOpen
                              ? (isDark
                                  ? AppTheme.successDark
                                  : AppTheme.successLight)
                              : (isDark
                                  ? AppTheme.errorDark
                                  : AppTheme.errorLight),
                          fontWeight: FontWeight.w600,
                        ),
                    textDirection: TextDirection.rtl,
                  ),
                  SizedBox(width: 2.w),
                  Container(
                    width: 8,
                    height: 8,
                    decoration: BoxDecoration(
                      color: isOpen
                          ? (isDark
                              ? AppTheme.successDark
                              : AppTheme.successLight)
                          : (isDark ? AppTheme.errorDark : AppTheme.errorLight),
                      shape: BoxShape.circle,
                    ),
                  ),
                  SizedBox(width: 2.w),
                  Text(
                    'ساعات کاری',
                    style: Theme.of(context).textTheme.titleMedium?.copyWith(
                          fontWeight: FontWeight.w600,
                          color: isDark
                              ? AppTheme.textPrimaryDark
                              : AppTheme.textPrimaryLight,
                        ),
                    textDirection: TextDirection.rtl,
                  ),
                  SizedBox(width: 2.w),
                  CustomIconWidget(
                    iconName: 'access_time',
                    color: isDark
                        ? AppTheme.textPrimaryDark
                        : AppTheme.textPrimaryLight,
                    size: 20,
                  ),
                ],
              ),
            ],
          ),

          if (_isExpanded) ...[
            SizedBox(height: 2.h),
            Divider(
              color: isDark ? AppTheme.dividerDark : AppTheme.dividerLight,
              thickness: 1,
            ),
            SizedBox(height: 1.h),

            // Weekly schedule
            ...(_getWeeklySchedule())
                .map((day) => Padding(
                      padding: EdgeInsets.symmetric(vertical: 0.5.h),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text(
                            day['hours'] as String,
                            style: Theme.of(context)
                                .textTheme
                                .bodyMedium
                                ?.copyWith(
                                  color: isDark
                                      ? AppTheme.textSecondaryDark
                                      : AppTheme.textSecondaryLight,
                                ),
                            textDirection: TextDirection.rtl,
                          ),
                          Text(
                            day['day'] as String,
                            style: Theme.of(context)
                                .textTheme
                                .bodyMedium
                                ?.copyWith(
                                  fontWeight: FontWeight.w500,
                                  color: isDark
                                      ? AppTheme.textPrimaryDark
                                      : AppTheme.textPrimaryLight,
                                ),
                            textDirection: TextDirection.rtl,
                          ),
                        ],
                      ),
                    ))
                .toList(),
          ],
        ],
      ),
    );
  }

  List<Map<String, String>> _getWeeklySchedule() {
    return [
      {'day': 'شنبه', 'hours': '۰۸:۰۰ - ۲۲:۰۰'},
      {'day': 'یکشنبه', 'hours': '۰۸:۰۰ - ۲۲:۰۰'},
      {'day': 'دوشنبه', 'hours': '۰۸:۰۰ - ۲۲:۰۰'},
      {'day': 'سه‌شنبه', 'hours': '۰۸:۰۰ - ۲۲:۰۰'},
      {'day': 'چهارشنبه', 'hours': '۰۸:۰۰ - ۲۲:۰۰'},
      {'day': 'پنج‌شنبه', 'hours': '۰۸:۰۰ - ۱۴:۰۰'},
      {'day': 'جمعه', 'hours': 'تعطیل'},
    ];
  }
}
