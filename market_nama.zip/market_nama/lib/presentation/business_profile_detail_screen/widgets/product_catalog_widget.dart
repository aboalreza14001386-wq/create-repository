import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';

class ProductCatalogWidget extends StatelessWidget {
  final List<Map<String, dynamic>> products;

  const ProductCatalogWidget({
    Key? key,
    required this.products,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final bool isDark = Theme.of(context).brightness == Brightness.dark;

    return Container(
      width: double.infinity,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.end,
        children: [
          // Section Header
          Row(
            mainAxisAlignment: MainAxisAlignment.end,
            children: [
              Text(
                'محصولات و خدمات',
                style: Theme.of(context).textTheme.titleLarge?.copyWith(
                      fontWeight: FontWeight.w700,
                      color: isDark
                          ? AppTheme.textPrimaryDark
                          : AppTheme.textPrimaryLight,
                    ),
                textDirection: TextDirection.rtl,
              ),
              SizedBox(width: 2.w),
              CustomIconWidget(
                iconName: 'inventory_2',
                color: isDark ? AppTheme.primaryDark : AppTheme.primaryLight,
                size: 24,
              ),
            ],
          ),

          SizedBox(height: 2.h),

          // Products Horizontal List
          Container(
            height: 28.h,
            child: ListView.separated(
              scrollDirection: Axis.horizontal,
              reverse: true, // RTL scrolling
              itemCount: products.length,
              separatorBuilder: (context, index) => SizedBox(width: 3.w),
              itemBuilder: (context, index) {
                final product = products[index];
                return _buildProductCard(context, product, isDark);
              },
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildProductCard(
      BuildContext context, Map<String, dynamic> product, bool isDark) {
    return GestureDetector(
      onTap: () => _showProductDetail(context, product),
      child: Container(
        width: 45.w,
        decoration: BoxDecoration(
          color: isDark ? AppTheme.cardDark : AppTheme.cardLight,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(
            color: isDark ? AppTheme.dividerDark : AppTheme.dividerLight,
            width: 1,
          ),
          boxShadow: [
            BoxShadow(
              color: isDark ? AppTheme.shadowDark : AppTheme.shadowLight,
              blurRadius: 8,
              offset: Offset(0, 2),
            ),
          ],
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.end,
          children: [
            // Product Image
            Container(
              width: double.infinity,
              height: 15.h,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.vertical(top: Radius.circular(12)),
                color: isDark ? AppTheme.dividerDark : AppTheme.dividerLight,
              ),
              child: ClipRRect(
                borderRadius: BorderRadius.vertical(top: Radius.circular(12)),
                child: CustomImageWidget(
                  imageUrl: product['image'] ?? '',
                  width: double.infinity,
                  height: 15.h,
                  fit: BoxFit.cover,
                ),
              ),
            ),

            // Product Details
            Expanded(
              child: Padding(
                padding: EdgeInsets.all(3.w),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.end,
                      children: [
                        // Product Name
                        Text(
                          product['name'] ?? 'نام محصول',
                          style:
                              Theme.of(context).textTheme.titleMedium?.copyWith(
                                    fontWeight: FontWeight.w600,
                                    color: isDark
                                        ? AppTheme.textPrimaryDark
                                        : AppTheme.textPrimaryLight,
                                  ),
                          textAlign: TextAlign.right,
                          textDirection: TextDirection.rtl,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                        ),

                        SizedBox(height: 0.5.h),

                        // Product Description
                        Text(
                          product['description'] ?? 'توضیحات محصول',
                          style:
                              Theme.of(context).textTheme.bodySmall?.copyWith(
                                    color: isDark
                                        ? AppTheme.textSecondaryDark
                                        : AppTheme.textSecondaryLight,
                                    height: 1.3,
                                  ),
                          textAlign: TextAlign.right,
                          textDirection: TextDirection.rtl,
                          maxLines: 2,
                          overflow: TextOverflow.ellipsis,
                        ),
                      ],
                    ),

                    // Price
                    Container(
                      padding: EdgeInsets.symmetric(
                          horizontal: 2.w, vertical: 0.5.h),
                      decoration: BoxDecoration(
                        color: (isDark
                                ? AppTheme.successDark
                                : AppTheme.successLight)
                            .withValues(alpha: 0.1),
                        borderRadius: BorderRadius.circular(8),
                      ),
                      child: Text(
                        '${_convertToPersianNumbers(_formatPrice(product['price'] ?? 0))} تومان',
                        style: Theme.of(context).textTheme.titleSmall?.copyWith(
                              color: isDark
                                  ? AppTheme.successDark
                                  : AppTheme.successLight,
                              fontWeight: FontWeight.w700,
                            ),
                        textDirection: TextDirection.rtl,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  void _showProductDetail(BuildContext context, Map<String, dynamic> product) {
    final bool isDark = Theme.of(context).brightness == Brightness.dark;

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (context) => Directionality(
        textDirection: TextDirection.rtl,
        child: Container(
          height: 70.h,
          decoration: BoxDecoration(
            color: isDark ? AppTheme.cardDark : AppTheme.cardLight,
            borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
          ),
          child: Column(
            children: [
              // Handle bar
              Container(
                width: 12.w,
                height: 0.5.h,
                margin: EdgeInsets.symmetric(vertical: 1.h),
                decoration: BoxDecoration(
                  color: isDark ? AppTheme.dividerDark : AppTheme.dividerLight,
                  borderRadius: BorderRadius.circular(2),
                ),
              ),

              Expanded(
                child: SingleChildScrollView(
                  padding: EdgeInsets.all(4.w),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.end,
                    children: [
                      // Product Image
                      Container(
                        width: double.infinity,
                        height: 30.h,
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(12),
                          color: isDark
                              ? AppTheme.dividerDark
                              : AppTheme.dividerLight,
                        ),
                        child: ClipRRect(
                          borderRadius: BorderRadius.circular(12),
                          child: CustomImageWidget(
                            imageUrl: product['image'] ?? '',
                            width: double.infinity,
                            height: 30.h,
                            fit: BoxFit.cover,
                          ),
                        ),
                      ),

                      SizedBox(height: 2.h),

                      // Product Name
                      Text(
                        product['name'] ?? 'نام محصول',
                        style:
                            Theme.of(context).textTheme.headlineSmall?.copyWith(
                                  fontWeight: FontWeight.w700,
                                  color: isDark
                                      ? AppTheme.textPrimaryDark
                                      : AppTheme.textPrimaryLight,
                                ),
                        textAlign: TextAlign.right,
                        textDirection: TextDirection.rtl,
                      ),

                      SizedBox(height: 1.h),

                      // Price
                      Container(
                        padding: EdgeInsets.symmetric(
                            horizontal: 4.w, vertical: 1.h),
                        decoration: BoxDecoration(
                          color: (isDark
                                  ? AppTheme.successDark
                                  : AppTheme.successLight)
                              .withValues(alpha: 0.1),
                          borderRadius: BorderRadius.circular(12),
                        ),
                        child: Text(
                          '${_convertToPersianNumbers(_formatPrice(product['price'] ?? 0))} تومان',
                          style:
                              Theme.of(context).textTheme.titleLarge?.copyWith(
                                    color: isDark
                                        ? AppTheme.successDark
                                        : AppTheme.successLight,
                                    fontWeight: FontWeight.w700,
                                  ),
                          textDirection: TextDirection.rtl,
                        ),
                      ),

                      SizedBox(height: 2.h),

                      // Description
                      Text(
                        'توضیحات محصول',
                        style:
                            Theme.of(context).textTheme.titleMedium?.copyWith(
                                  fontWeight: FontWeight.w600,
                                  color: isDark
                                      ? AppTheme.textPrimaryDark
                                      : AppTheme.textPrimaryLight,
                                ),
                        textDirection: TextDirection.rtl,
                      ),

                      SizedBox(height: 1.h),

                      Text(
                        product['description'] ??
                            'توضیحات کاملی از محصول در اینجا قرار می‌گیرد. این محصول با کیفیت بالا و قیمت مناسب ارائه می‌شود.',
                        style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                              color: isDark
                                  ? AppTheme.textSecondaryDark
                                  : AppTheme.textSecondaryLight,
                              height: 1.5,
                            ),
                        textAlign: TextAlign.right,
                        textDirection: TextDirection.rtl,
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  String _formatPrice(dynamic price) {
    if (price == null) return '0';

    // Convert to integer if it's a double with no decimal part
    if (price is double && price == price.toInt()) {
      price = price.toInt();
    }

    // Format with thousands separator
    String priceStr = price.toString();
    String result = '';
    int count = 0;

    for (int i = priceStr.length - 1; i >= 0; i--) {
      if (count == 3) {
        result = ',' + result;
        count = 0;
      }
      result = priceStr[i] + result;
      count++;
    }

    return result;
  }

  String _convertToPersianNumbers(String input) {
    const english = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9'];
    const persian = ['۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹'];

    String result = input;
    for (int i = 0; i < english.length; i++) {
      result = result.replaceAll(english[i], persian[i]);
    }
    return result;
  }
}
