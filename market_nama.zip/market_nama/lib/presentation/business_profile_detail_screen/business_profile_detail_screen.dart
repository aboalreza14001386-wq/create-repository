import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../core/app_export.dart';
import './widgets/business_header_widget.dart';
import './widgets/business_hours_widget.dart';
import './widgets/contact_actions_widget.dart';
import './widgets/product_catalog_widget.dart';
import './widgets/reviews_section_widget.dart';

class BusinessProfileDetailScreen extends StatefulWidget {
  const BusinessProfileDetailScreen({Key? key}) : super(key: key);

  @override
  State<BusinessProfileDetailScreen> createState() =>
      _BusinessProfileDetailScreenState();
}

class _BusinessProfileDetailScreenState
    extends State<BusinessProfileDetailScreen> {
  bool _isLoading = false;

  // Mock business data
  final Map<String, dynamic> _businessData = {
    "id": 1,
    "name": "رستوران سنتی کوهستان",
    "category": "رستوران",
    "address": "تهران، خیابان ولیعصر، نرسیده به پارک ملت، پلاک ۱۲۳",
    "phone": "02188776655",
    "heroImage":
        "https://images.pexels.com/photos/262978/pexels-photo-262978.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1",
    "rating": 4.3,
    "reviewCount": 127,
    "isOpen": true,
    "isVisible": true,
  };

  // Mock products data
  final List<Map<String, dynamic>> _products = [
    {
      "id": 1,
      "name": "کباب کوبیده",
      "description": "کباب کوبیده تازه با گوشت مرغوب و برنج ایرانی",
      "price": 85000,
      "image":
          "https://images.pexels.com/photos/4518843/pexels-photo-4518843.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1",
    },
    {
      "id": 2,
      "name": "خورشت قیمه",
      "description": "خورشت قیمه سنتی با آلو و سیب‌زمینی",
      "price": 65000,
      "image":
          "https://images.pexels.com/photos/5737241/pexels-photo-5737241.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1",
    },
    {
      "id": 3,
      "name": "آش رشته",
      "description": "آش رشته خانگی با سبزیجات تازه",
      "price": 45000,
      "image":
          "https://images.pexels.com/photos/5737443/pexels-photo-5737443.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1",
    },
    {
      "id": 4,
      "name": "جوجه کباب",
      "description": "جوجه کباب مخصوص با زعفران و برنج",
      "price": 95000,
      "image":
          "https://images.pexels.com/photos/4518843/pexels-photo-4518843.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1",
    },
  ];

  // Mock reviews data
  final List<Map<String, dynamic>> _reviews = [
    {
      "id": 1,
      "customerName": "احمد محمدی",
      "rating": 5,
      "comment":
          "غذاهای بسیار خوشمزه و محیط دنج. کیفیت عالی و قیمت مناسب. حتماً دوباره می‌آیم.",
      "date": "2025-01-10",
    },
    {
      "id": 2,
      "customerName": "فاطمه احمدی",
      "rating": 4,
      "comment": "کباب کوبیده فوق‌العاده بود. فقط انتظار کمی طولانی بود.",
      "date": "2025-01-08",
    },
    {
      "id": 3,
      "customerName": "علی رضایی",
      "rating": 5,
      "comment": "بهترین رستوران سنتی منطقه. خورشت قیمه عالی بود.",
      "date": "2025-01-05",
    },
    {
      "id": 4,
      "customerName": "مریم کریمی",
      "rating": 4,
      "comment": "محیط خوب و غذای خوشمزه. پیشنهاد می‌کنم.",
      "date": "2025-01-03",
    },
    {
      "id": 5,
      "customerName": "حسن موسوی",
      "rating": 3,
      "comment": "غذا خوب بود اما سرویس کمی کند بود.",
      "date": "2024-12-28",
    },
  ];

  @override
  Widget build(BuildContext context) {
    final bool isDark = Theme.of(context).brightness == Brightness.dark;

    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        backgroundColor:
            isDark ? AppTheme.backgroundDark : AppTheme.backgroundLight,
        body: SafeArea(
          child: Column(
            children: [
              // Custom App Bar
              _buildAppBar(context, isDark),

              // Main Content
              Expanded(
                child: _businessData['isVisible'] == true
                    ? _buildMainContent(isDark)
                    : _buildBusinessHiddenMessage(isDark),
              ),
            ],
          ),
        ),

        // Floating Action Button for Reviews
        floatingActionButton: _businessData['isVisible'] == true
            ? FloatingActionButton.extended(
                onPressed: () => _showWriteReviewBottomSheet(context),
                backgroundColor:
                    isDark ? AppTheme.secondaryDark : AppTheme.secondaryLight,
                foregroundColor: AppTheme.onSecondaryLight,
                icon: CustomIconWidget(
                  iconName: 'rate_review',
                  color: AppTheme.onSecondaryLight,
                  size: 20,
                ),
                label: Text(
                  'نظر دهید',
                  style: TextStyle(
                    color: AppTheme.onSecondaryLight,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              )
            : null,
      ),
    );
  }

  Widget _buildAppBar(BuildContext context, bool isDark) {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 4.w, vertical: 1.h),
      decoration: BoxDecoration(
        color: isDark ? AppTheme.surfaceDark : AppTheme.surfaceLight,
        border: Border(
          bottom: BorderSide(
            color: isDark ? AppTheme.dividerDark : AppTheme.dividerLight,
            width: 1,
          ),
        ),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          // Share Button
          IconButton(
            onPressed: () => _shareBusinessProfile(context),
            icon: CustomIconWidget(
              iconName: 'share',
              color:
                  isDark ? AppTheme.textPrimaryDark : AppTheme.textPrimaryLight,
              size: 24,
            ),
          ),

          // Title
          Text(
            'جزئیات کسب و کار',
            style: Theme.of(context).textTheme.titleLarge?.copyWith(
                  fontWeight: FontWeight.w600,
                  color: isDark
                      ? AppTheme.textPrimaryDark
                      : AppTheme.textPrimaryLight,
                ),
          ),

          // Back Button
          IconButton(
            onPressed: () => Navigator.of(context).pop(),
            icon: CustomIconWidget(
              iconName: 'arrow_back',
              color: Colors.black,
              size: 24,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildMainContent(bool isDark) {
    return RefreshIndicator(
      onRefresh: _refreshBusinessData,
      color: isDark ? AppTheme.primaryDark : AppTheme.primaryLight,
      backgroundColor: isDark ? AppTheme.surfaceDark : AppTheme.surfaceLight,
      child: SingleChildScrollView(
        physics: AlwaysScrollableScrollPhysics(),
        padding: EdgeInsets.all(4.w),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.end,
          children: [
            // Business Header
            BusinessHeaderWidget(businessData: _businessData),

            SizedBox(height: 3.h),

            // Business Hours
            BusinessHoursWidget(businessData: _businessData),

            SizedBox(height: 3.h),

            // Contact Actions
            ContactActionsWidget(businessData: _businessData),

            SizedBox(height: 4.h),

            // Product Catalog
            if (_products.isNotEmpty) ...[
              ProductCatalogWidget(products: _products),
              SizedBox(height: 4.h),
            ],

            // Reviews Section
            ReviewsSectionWidget(
              reviews: _reviews,
              averageRating: _businessData['rating']?.toDouble() ?? 0.0,
              totalReviews: _businessData['reviewCount'] ?? 0,
            ),

            // Bottom padding for FAB
            SizedBox(height: 10.h),
          ],
        ),
      ),
    );
  }

  Widget _buildBusinessHiddenMessage(bool isDark) {
    return Center(
      child: Padding(
        padding: EdgeInsets.all(8.w),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            CustomIconWidget(
              iconName: 'visibility_off',
              color: isDark
                  ? AppTheme.textSecondaryDark
                  : AppTheme.textSecondaryLight,
              size: 64,
            ),
            SizedBox(height: 3.h),
            Text(
              'کسب و کار موقتاً غیرفعال',
              style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                    fontWeight: FontWeight.w600,
                    color: isDark
                        ? AppTheme.textPrimaryDark
                        : AppTheme.textPrimaryLight,
                  ),
              textAlign: TextAlign.center,
              textDirection: TextDirection.rtl,
            ),
            SizedBox(height: 2.h),
            Text(
              'این کسب و کار در حال حاضر غیرفعال است و اطلاعات آن قابل مشاهده نیست.',
              style: Theme.of(context).textTheme.bodyLarge?.copyWith(
                    color: isDark
                        ? AppTheme.textSecondaryDark
                        : AppTheme.textSecondaryLight,
                    height: 1.5,
                  ),
              textAlign: TextAlign.center,
              textDirection: TextDirection.rtl,
            ),
            SizedBox(height: 4.h),
            ElevatedButton(
              onPressed: () => Navigator.of(context).pop(),
              child: Text(
                'بازگشت به جستجو',
                style: TextStyle(
                  color: AppTheme.onPrimaryLight,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _refreshBusinessData() async {
    setState(() {
      _isLoading = true;
    });

    // Simulate API call
    await Future.delayed(Duration(seconds: 1));

    setState(() {
      _isLoading = false;
    });

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          'اطلاعات به‌روزرسانی شد',
          textDirection: TextDirection.rtl,
        ),
        backgroundColor: Theme.of(context).brightness == Brightness.dark
            ? AppTheme.successDark
            : AppTheme.successLight,
      ),
    );
  }

  void _shareBusinessProfile(BuildContext context) {
    final businessName = _businessData['name'] ?? 'کسب و کار';
    final businessAddress = _businessData['address'] ?? '';
    final businessPhone = _businessData['phone'] ?? '';

    // In a real app, this would use the share_plus package
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          'اشتراک‌گذاری: $businessName\n$businessAddress\n$businessPhone',
          textDirection: TextDirection.rtl,
        ),
        duration: Duration(seconds: 3),
        backgroundColor: Theme.of(context).brightness == Brightness.dark
            ? AppTheme.primaryDark
            : AppTheme.primaryLight,
      ),
    );
  }

  void _showWriteReviewBottomSheet(BuildContext context) {
    final bool isDark = Theme.of(context).brightness == Brightness.dark;
    int selectedRating = 0;
    final TextEditingController commentController = TextEditingController();

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (context) => StatefulBuilder(
        builder: (context, setModalState) => Directionality(
          textDirection: TextDirection.rtl,
          child: Container(
            height: 60.h,
            decoration: BoxDecoration(
              color: isDark ? AppTheme.cardDark : AppTheme.cardLight,
              borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
            ),
            child: Column(
              children: [
                // Handle bar
                Container(
                  width: 12.w,
                  height: 0.5.h,
                  margin: EdgeInsets.symmetric(vertical: 1.h),
                  decoration: BoxDecoration(
                    color:
                        isDark ? AppTheme.dividerDark : AppTheme.dividerLight,
                    borderRadius: BorderRadius.circular(2),
                  ),
                ),

                Expanded(
                  child: Padding(
                    padding: EdgeInsets.all(4.w),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.end,
                      children: [
                        // Title
                        Text(
                          'نظر خود را بنویسید',
                          style:
                              Theme.of(context).textTheme.titleLarge?.copyWith(
                                    fontWeight: FontWeight.w700,
                                    color: isDark
                                        ? AppTheme.textPrimaryDark
                                        : AppTheme.textPrimaryLight,
                                  ),
                          textDirection: TextDirection.rtl,
                        ),

                        SizedBox(height: 3.h),

                        // Rating Selector
                        Text(
                          'امتیاز شما:',
                          style:
                              Theme.of(context).textTheme.titleMedium?.copyWith(
                                    fontWeight: FontWeight.w600,
                                    color: isDark
                                        ? AppTheme.textPrimaryDark
                                        : AppTheme.textPrimaryLight,
                                  ),
                          textDirection: TextDirection.rtl,
                        ),

                        SizedBox(height: 1.h),

                        Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: List.generate(5, (index) {
                            final starIndex = 5 - index; // RTL order
                            return GestureDetector(
                              onTap: () {
                                setModalState(() {
                                  selectedRating = starIndex;
                                });
                              },
                              child: Padding(
                                padding: EdgeInsets.symmetric(horizontal: 1.w),
                                child: CustomIconWidget(
                                  iconName: selectedRating >= starIndex
                                      ? 'star'
                                      : 'star_border',
                                  color: AppTheme.warningLight,
                                  size: 32,
                                ),
                              ),
                            );
                          }),
                        ),

                        SizedBox(height: 3.h),

                        // Comment Input
                        Text(
                          'نظر شما:',
                          style:
                              Theme.of(context).textTheme.titleMedium?.copyWith(
                                    fontWeight: FontWeight.w600,
                                    color: isDark
                                        ? AppTheme.textPrimaryDark
                                        : AppTheme.textPrimaryLight,
                                  ),
                          textDirection: TextDirection.rtl,
                        ),

                        SizedBox(height: 1.h),

                        Expanded(
                          child: TextField(
                            controller: commentController,
                            maxLines: null,
                            expands: true,
                            textAlign: TextAlign.right,
                            textDirection: TextDirection.rtl,
                            decoration: InputDecoration(
                              hintText:
                                  'نظر خود را در مورد این کسب و کار بنویسید...',
                              hintStyle: TextStyle(
                                color: isDark
                                    ? AppTheme.textDisabledDark
                                    : AppTheme.textDisabledLight,
                              ),
                              border: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(12),
                                borderSide: BorderSide(
                                  color: isDark
                                      ? AppTheme.dividerDark
                                      : AppTheme.dividerLight,
                                ),
                              ),
                              focusedBorder: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(12),
                                borderSide: BorderSide(
                                  color: isDark
                                      ? AppTheme.primaryDark
                                      : AppTheme.primaryLight,
                                  width: 2,
                                ),
                              ),
                            ),
                            style: TextStyle(
                              color: isDark
                                  ? AppTheme.textPrimaryDark
                                  : AppTheme.textPrimaryLight,
                            ),
                          ),
                        ),

                        SizedBox(height: 3.h),

                        // Submit Button
                        Container(
                          width: double.infinity,
                          height: 6.h,
                          child: ElevatedButton(
                            onPressed: selectedRating > 0
                                ? () => _submitReview(context, selectedRating,
                                    commentController.text)
                                : null,
                            style: ElevatedButton.styleFrom(
                              backgroundColor: selectedRating > 0
                                  ? (isDark
                                      ? AppTheme.primaryDark
                                      : AppTheme.primaryLight)
                                  : (isDark
                                      ? AppTheme.textDisabledDark
                                      : AppTheme.textDisabledLight),
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(12),
                              ),
                            ),
                            child: Text(
                              'ارسال نظر',
                              style: TextStyle(
                                color: AppTheme.onPrimaryLight,
                                fontWeight: FontWeight.w600,
                                fontSize: 16.sp,
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  void _submitReview(BuildContext context, int rating, String comment) {
    Navigator.of(context).pop();

    // In a real app, this would submit to the API
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          'نظر شما با موفقیت ثبت شد',
          textDirection: TextDirection.rtl,
        ),
        backgroundColor: Theme.of(context).brightness == Brightness.dark
            ? AppTheme.successDark
            : AppTheme.successLight,
      ),
    );

    // Add the new review to the list (for demo purposes)
    setState(() {
      _reviews.insert(0, {
        "id": _reviews.length + 1,
        "customerName": "شما",
        "rating": rating,
        "comment": comment.isNotEmpty ? comment : null,
        "date": DateTime.now().toIso8601String(),
      });

      // Recalculate average rating
      double totalRating =
          _reviews.fold(0.0, (sum, review) => sum + (review['rating'] ?? 0));
      _businessData['rating'] = totalRating / _reviews.length;
      _businessData['reviewCount'] = _reviews.length;
    });
  }
}
