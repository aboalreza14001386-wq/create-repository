import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:sizer/sizer.dart';
import 'package:google_fonts/google_fonts.dart';

import '../../core/app_export.dart';
import '../../theme/app_theme.dart';
import './widgets/business_info_header_widget.dart';
import './widgets/review_guidelines_widget.dart';
import './widgets/review_text_field_widget.dart';
import './widgets/star_rating_widget.dart';
import 'widgets/business_info_header_widget.dart';
import 'widgets/review_guidelines_widget.dart';
import 'widgets/review_text_field_widget.dart';
import 'widgets/star_rating_widget.dart';

class WriteReviewScreen extends StatefulWidget {
  const WriteReviewScreen({Key? key}) : super(key: key);

  @override
  State<WriteReviewScreen> createState() => _WriteReviewScreenState();
}

class _WriteReviewScreenState extends State<WriteReviewScreen> {
  final TextEditingController _reviewController = TextEditingController();
  int _selectedRating = 0;
  bool _isSubmitting = false;
  String _reviewText = '';

  // Mock business data
  final Map<String, dynamic> _businessData = {
    "id": 1,
    "name": "رستوران سنتی کوهستان",
    "category": "رستوران و غذا",
    "image":
        "https://images.pexels.com/photos/262978/pexels-photo-262978.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1",
    "address": "تهران، خیابان ولیعصر، پلاک ۱۲۳",
    "phone": "۰۲۱-۸۸۷۷۶۶۵۵",
    "rating": 4.2,
    "reviewCount": 156,
  };

  @override
  void initState() {
    super.initState();
    _reviewController.addListener(() {
      setState(() {
        _reviewText = _reviewController.text;
      });
    });
  }

  @override
  void dispose() {
    _reviewController.dispose();
    super.dispose();
  }

  bool get _canSubmit => _selectedRating > 0 && !_isSubmitting;

  Future<void> _submitReview() async {
    if (!_canSubmit) return;

    // Validate review content
    if (_reviewText.trim().length < 10 && _reviewText.trim().isNotEmpty) {
      _showErrorMessage('نظر شما باید حداقل ۱۰ کاراکتر باشد');
      return;
    }

    setState(() {
      _isSubmitting = true;
    });

    try {
      // Simulate API call
      await Future.delayed(const Duration(seconds: 2));

      // Show success toast in Farsi
      Fluttertoast.showToast(
        msg: "نظر شما با موفقیت ثبت شد",
        toastLength: Toast.LENGTH_LONG,
        gravity: ToastGravity.BOTTOM,
        backgroundColor: AppTheme.getSuccessColor(
            Theme.of(context).brightness == Brightness.light),
        textColor: Colors.white,
        fontSize: 14.sp,
      );

      // Provide haptic feedback
      HapticFeedback.lightImpact();

      // Navigate back to business profile detail
      Navigator.pushReplacementNamed(
          context, '/business-profile-detail-screen');
    } catch (e) {
      _showErrorMessage('خطا در ارسال نظر. لطفاً دوباره تلاش کنید');
    } finally {
      if (mounted) {
        setState(() {
          _isSubmitting = false;
        });
      }
    }
  }

  void _showErrorMessage(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          message,
          style: GoogleFonts.inter(
            fontSize: 14.sp,
            fontWeight: FontWeight.w400,
          ),
          textDirection: TextDirection.rtl,
        ),
        backgroundColor: AppTheme.getErrorColor(
            Theme.of(context).brightness == Brightness.light),
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(12.0),
        ),
      ),
    );
  }

  void _saveDraft() {
    // Save draft locally (simplified implementation)
    if (_selectedRating > 0 || _reviewText.trim().isNotEmpty) {
      // In a real app, this would save to local storage
      Fluttertoast.showToast(
        msg: "پیش‌نویس ذخیره شد",
        toastLength: Toast.LENGTH_SHORT,
        gravity: ToastGravity.BOTTOM,
        backgroundColor: AppTheme.lightTheme.colorScheme.primary,
        textColor: Colors.white,
        fontSize: 14.sp,
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;

    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        backgroundColor:
            isDark ? AppTheme.backgroundDark : AppTheme.backgroundLight,
        body: SafeArea(
          child: Column(
            children: [
              // Header with business info and close button
              BusinessInfoHeaderWidget(
                businessName: _businessData["name"] as String,
                businessCategory: _businessData["category"] as String,
                businessImage: _businessData["image"] as String,
                onClose: () {
                  _saveDraft();
                  Navigator.pop(context);
                },
              ),

              // Scrollable content
              Expanded(
                child: SingleChildScrollView(
                  padding: EdgeInsets.symmetric(
                    horizontal: 4.w,
                    vertical: 2.h,
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      SizedBox(height: 2.h),

                      // Title
                      Text(
                        'نظر خود را درباره این کسب‌وکار بنویسید',
                        style: GoogleFonts.inter(
                          fontSize: 18.sp,
                          fontWeight: FontWeight.w600,
                          color: isDark
                              ? AppTheme.textPrimaryDark
                              : AppTheme.textPrimaryLight,
                        ),
                        textAlign: TextAlign.center,
                      ),

                      SizedBox(height: 4.h),

                      // Star rating
                      StarRatingWidget(
                        rating: _selectedRating,
                        onRatingChanged: (rating) {
                          setState(() {
                            _selectedRating = rating;
                          });
                          HapticFeedback.selectionClick();
                        },
                        starSize: 48.0,
                      ),

                      SizedBox(height: 2.h),

                      // Rating description
                      Text(
                        _getRatingDescription(_selectedRating),
                        style: GoogleFonts.inter(
                          fontSize: 14.sp,
                          fontWeight: FontWeight.w500,
                          color: AppTheme.secondaryLight,
                        ),
                        textAlign: TextAlign.center,
                      ),

                      SizedBox(height: 4.h),

                      // Review text field
                      ReviewTextFieldWidget(
                        controller: _reviewController,
                        hintText: 'تجربه خود را با ما به اشتراک بگذارید...',
                        maxLength: 500,
                        maxLines: 5,
                        onChanged: (value) {
                          setState(() {
                            _reviewText = value;
                          });
                        },
                      ),

                      SizedBox(height: 3.h),

                      // Review guidelines
                      const ReviewGuidelinesWidget(),

                      SizedBox(height: 4.h),
                    ],
                  ),
                ),
              ),

              // Bottom submit button
              Container(
                padding: EdgeInsets.symmetric(
                  horizontal: 4.w,
                  vertical: 2.h,
                ),
                decoration: BoxDecoration(
                  color: isDark ? AppTheme.surfaceDark : AppTheme.surfaceLight,
                  border: Border(
                    top: BorderSide(
                      color:
                          isDark ? AppTheme.dividerDark : AppTheme.dividerLight,
                      width: 1.0,
                    ),
                  ),
                ),
                child: SizedBox(
                  width: double.infinity,
                  height: 6.h,
                  child: ElevatedButton(
                    onPressed: _canSubmit ? _submitReview : null,
                    style: ElevatedButton.styleFrom(
                      backgroundColor: _canSubmit
                          ? AppTheme.primaryLight
                          : (isDark
                              ? AppTheme.textDisabledDark
                              : AppTheme.textDisabledLight),
                      foregroundColor: _canSubmit
                          ? AppTheme.onPrimaryLight
                          : (isDark
                              ? AppTheme.textSecondaryDark
                              : AppTheme.textSecondaryLight),
                      elevation: _canSubmit ? 2.0 : 0.0,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12.0),
                      ),
                    ),
                    child: _isSubmitting
                        ? SizedBox(
                            width: 24,
                            height: 24,
                            child: CircularProgressIndicator(
                              strokeWidth: 2.0,
                              valueColor: AlwaysStoppedAnimation<Color>(
                                AppTheme.onPrimaryLight,
                              ),
                            ),
                          )
                        : Text(
                            'ارسال نظر',
                            style: GoogleFonts.inter(
                              fontSize: 16.sp,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  String _getRatingDescription(int rating) {
    switch (rating) {
      case 1:
        return 'خیلی بد';
      case 2:
        return 'بد';
      case 3:
        return 'متوسط';
      case 4:
        return 'خوب';
      case 5:
        return 'عالی';
      default:
        return 'امتیاز خود را انتخاب کنید';
    }
  }
}