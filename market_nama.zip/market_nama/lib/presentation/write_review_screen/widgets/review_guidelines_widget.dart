import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';
import 'package:google_fonts/google_fonts.dart';

import '../../../core/app_export.dart';
import '../../../theme/app_theme.dart';
import '../../../widgets/custom_icon_widget.dart';

class ReviewGuidelinesWidget extends StatefulWidget {
  const ReviewGuidelinesWidget({Key? key}) : super(key: key);

  @override
  State<ReviewGuidelinesWidget> createState() => _ReviewGuidelinesWidgetState();
}

class _ReviewGuidelinesWidgetState extends State<ReviewGuidelinesWidget> {
  bool _isExpanded = false;

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;

    return Container(
      decoration: BoxDecoration(
        color: isDark ? AppTheme.cardDark : AppTheme.cardLight,
        borderRadius: BorderRadius.circular(12.0),
        border: Border.all(
          color: isDark ? AppTheme.dividerDark : AppTheme.dividerLight,
          width: 1.0,
        ),
      ),
      child: Column(
        children: [
          GestureDetector(
            onTap: () {
              setState(() {
                _isExpanded = !_isExpanded;
              });
            },
            child: Container(
              padding: EdgeInsets.symmetric(
                horizontal: 4.w,
                vertical: 2.h,
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Expanded(
                    child: Text(
                      'راهنمای نوشتن نظر',
                      style: GoogleFonts.inter(
                        fontSize: 14.sp,
                        fontWeight: FontWeight.w600,
                        color: isDark
                            ? AppTheme.textPrimaryDark
                            : AppTheme.textPrimaryLight,
                      ),
                      textDirection: TextDirection.rtl,
                    ),
                  ),
                  CustomIconWidget(
                    iconName: _isExpanded ? 'expand_less' : 'expand_more',
                    color: isDark
                        ? AppTheme.textSecondaryDark
                        : AppTheme.textSecondaryLight,
                    size: 24,
                  ),
                ],
              ),
            ),
          ),
          if (_isExpanded) ...[
            Container(
              width: double.infinity,
              height: 1,
              color: isDark ? AppTheme.dividerDark : AppTheme.dividerLight,
            ),
            Container(
              padding: EdgeInsets.symmetric(
                horizontal: 4.w,
                vertical: 2.h,
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  _buildGuidelineItem(
                    '• نظر خود را بر اساس تجربه واقعی بنویسید',
                    isDark,
                  ),
                  SizedBox(height: 1.h),
                  _buildGuidelineItem(
                    '• از زبان محترمانه و مودبانه استفاده کنید',
                    isDark,
                  ),
                  SizedBox(height: 1.h),
                  _buildGuidelineItem(
                    '• جزئیات مفید برای سایر مشتریان ارائه دهید',
                    isDark,
                  ),
                  SizedBox(height: 1.h),
                  _buildGuidelineItem(
                    '• از نوشتن اطلاعات شخصی خودداری کنید',
                    isDark,
                  ),
                  SizedBox(height: 1.h),
                  _buildGuidelineItem(
                    '• نظرات تبلیغاتی یا نامربوط مجاز نیست',
                    isDark,
                  ),
                ],
              ),
            ),
          ],
        ],
      ),
    );
  }

  Widget _buildGuidelineItem(String text, bool isDark) {
    return Text(
      text,
      style: GoogleFonts.inter(
        fontSize: 12.sp,
        fontWeight: FontWeight.w400,
        color:
            isDark ? AppTheme.textSecondaryDark : AppTheme.textSecondaryLight,
        height: 1.4,
      ),
      textDirection: TextDirection.rtl,
    );
  }
}