import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';

class StarRatingWidget extends StatefulWidget {
  final int rating;
  final Function(int) onRatingChanged;
  final double starSize;
  final bool isInteractive;

  const StarRatingWidget({
    Key? key,
    required this.rating,
    required this.onRatingChanged,
    this.starSize = 40.0,
    this.isInteractive = true,
  }) : super(key: key);

  @override
  State<StarRatingWidget> createState() => _StarRatingWidgetState();
}

class _StarRatingWidgetState extends State<StarRatingWidget> {
  int _hoveredRating = 0;

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: List.generate(5, (index) {
        final starIndex = index + 1;
        final isSelected = starIndex <= widget.rating;
        final isHovered = starIndex <= _hoveredRating;

        return GestureDetector(
          onTap: widget.isInteractive
              ? () {
                  widget.onRatingChanged(starIndex);
                }
              : null,
          child: MouseRegion(
            onEnter: (_) {
              if (widget.isInteractive) {
                setState(() {
                  _hoveredRating = starIndex;
                });
              }
            },
            onExit: (_) {
              if (widget.isInteractive) {
                setState(() {
                  _hoveredRating = 0;
                });
              }
            },
            child: Container(
              padding: EdgeInsets.all(1.w),
              child: CustomIconWidget(
                iconName: (isSelected || isHovered) ? 'star' : 'star_border',
                color: (isSelected || isHovered)
                    ? AppTheme.secondaryLight
                    : AppTheme.lightTheme.colorScheme.outline,
                size: widget.starSize,
              ),
            ),
          ),
        );
      }),
    );
  }
}
