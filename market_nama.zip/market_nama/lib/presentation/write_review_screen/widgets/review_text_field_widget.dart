import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';
import 'package:google_fonts/google_fonts.dart';

import '../../../core/app_export.dart';
import '../../../theme/app_theme.dart';

class ReviewTextFieldWidget extends StatefulWidget {
  final TextEditingController controller;
  final String hintText;
  final int maxLength;
  final int maxLines;
  final Function(String)? onChanged;

  const ReviewTextFieldWidget({
    Key? key,
    required this.controller,
    required this.hintText,
    this.maxLength = 500,
    this.maxLines = 5,
    this.onChanged,
  }) : super(key: key);

  @override
  State<ReviewTextFieldWidget> createState() => _ReviewTextFieldWidgetState();
}

class _ReviewTextFieldWidgetState extends State<ReviewTextFieldWidget> {
  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Container(
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(12.0),
            border: Border.all(
              color: isDark ? AppTheme.dividerDark : AppTheme.dividerLight,
              width: 1.0,
            ),
          ),
          child: TextField(
            controller: widget.controller,
            maxLength: widget.maxLength,
            maxLines: widget.maxLines,
            textDirection: TextDirection.rtl,
            textAlign: TextAlign.right,
            onChanged: widget.onChanged,
            style: GoogleFonts.inter(
              fontSize: 14.sp,
              fontWeight: FontWeight.w400,
              color:
                  isDark ? AppTheme.textPrimaryDark : AppTheme.textPrimaryLight,
            ),
            decoration: InputDecoration(
              hintText: widget.hintText,
              hintStyle: GoogleFonts.inter(
                fontSize: 14.sp,
                fontWeight: FontWeight.w400,
                color: isDark
                    ? AppTheme.textDisabledDark
                    : AppTheme.textDisabledLight,
              ),
              border: InputBorder.none,
              contentPadding: EdgeInsets.symmetric(
                horizontal: 4.w,
                vertical: 2.h,
              ),
              counterStyle: GoogleFonts.inter(
                fontSize: 12.sp,
                color: isDark
                    ? AppTheme.textSecondaryDark
                    : AppTheme.textSecondaryLight,
              ),
            ),
          ),
        ),
        SizedBox(height: 1.h),
        Text(
          'نظر شما به بهبود کیفیت خدمات کمک می‌کند',
          style: GoogleFonts.inter(
            fontSize: 12.sp,
            fontWeight: FontWeight.w400,
            color: isDark
                ? AppTheme.textSecondaryDark
                : AppTheme.textSecondaryLight,
          ),
          textDirection: TextDirection.rtl,
        ),
      ],
    );
  }
}