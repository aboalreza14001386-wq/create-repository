import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';

class EmptyStateWidget extends StatelessWidget {
  final bool isSearching;
  final bool isBusinessSearch;

  const EmptyStateWidget({
    Key? key,
    required this.isSearching,
    required this.isBusinessSearch,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.all(8.w),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          CustomIconWidget(
            iconName: isSearching ? 'search_off' : 'store',
            color: AppTheme.lightTheme.colorScheme.onSurfaceVariant,
            size: 20.w,
          ),
          SizedBox(height: 4.h),
          Text(
            isSearching
                ? 'نتیجه‌ای یافت نشد'
                : isBusinessSearch
                    ? 'کسب و کارهای محلی را جستجو کنید'
                    : 'محصولات مورد نظر خود را پیدا کنید',
            textAlign: TextAlign.center,
            style: AppTheme.lightTheme.textTheme.titleMedium?.copyWith(
              fontWeight: FontWeight.w600,
            ),
          ),
          SizedBox(height: 2.h),
          Text(
            isSearching
                ? 'لطفاً کلمات کلیدی دیگری را امتحان کنید'
                : isBusinessSearch
                    ? 'نام کسب و کار یا دسته‌بندی مورد نظر را وارد کنید'
                    : 'نام محصول مورد نظر خود را جستجو کنید',
            textAlign: TextAlign.center,
            style: AppTheme.lightTheme.textTheme.bodyMedium?.copyWith(
              color: AppTheme.lightTheme.colorScheme.onSurfaceVariant,
            ),
          ),
        ],
      ),
    );
  }
}
