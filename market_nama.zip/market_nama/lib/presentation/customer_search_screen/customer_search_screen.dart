import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../core/app_export.dart';
import './widgets/business_card_widget.dart';
import './widgets/empty_state_widget.dart';
import './widgets/search_bar_widget.dart';
import './widgets/search_history_widget.dart';
import './widgets/search_toggle_widget.dart';

class CustomerSearchScreen extends StatefulWidget {
  const CustomerSearchScreen({Key? key}) : super(key: key);

  @override
  State<CustomerSearchScreen> createState() => _CustomerSearchScreenState();
}

class _CustomerSearchScreenState extends State<CustomerSearchScreen>
    with TickerProviderStateMixin {
  late TabController _tabController;
  final TextEditingController _searchController = TextEditingController();

  bool _isBusinessSearch = true;
  List<Map<String, dynamic>> _searchResults = [];
  List<String> _searchHistory = [];
  Set<int> _favoriteBusinessIds = {};
  bool _isLoading = false;
  bool _hasSearched = false;

  // Mock data for businesses
  final List<Map<String, dynamic>> _allBusinesses = [
    {
      "id": 1,
      "name": "رستوران سنتی کوهستان",
      "category": "رستوران",
      "address": "خیابان ولیعصر، پلاک ۱۲۳",
      "phone": "۰۲۱-۸۸۷۷۶۶۵۵",
      "rating": 4.5,
      "image":
          "https://images.pexels.com/photos/262978/pexels-photo-262978.jpeg?auto=compress&cs=tinysrgb&w=800",
      "products": ["کباب کوبیده", "جوجه کباب", "چلو خورشت"]
    },
    {
      "id": 2,
      "name": "کافه نگین",
      "category": "کافه",
      "address": "میدان تجریش، کوچه باغ فردوس",
      "phone": "۰۲۱-۲۲۳۳۴۴۵۵",
      "rating": 4.2,
      "image":
          "https://images.pexels.com/photos/302899/pexels-photo-302899.jpeg?auto=compress&cs=tinysrgb&w=800",
      "products": ["قهوه اسپرسو", "کیک شکلاتی", "ساندویچ"]
    },
    {
      "id": 3,
      "name": "فروشگاه موبایل تکنو",
      "category": "فروشگاه موبایل",
      "address": "بازار بزرگ، طبقه دوم",
      "phone": "۰۲۱-۵۵۴۴۳۳۲۲",
      "rating": 4.0,
      "image":
          "https://images.pexels.com/photos/1092644/pexels-photo-1092644.jpeg?auto=compress&cs=tinysrgb&w=800",
      "products": ["گوشی هوشمند", "لوازم جانبی", "تعمیرات"]
    },
    {
      "id": 4,
      "name": "آرایشگاه بانوان زیبا",
      "category": "آرایشگاه",
      "address": "خیابان انقلاب، کوچه دانشگاه",
      "phone": "۰۲۱-۶۶۷۷۸۸۹۹",
      "rating": 4.7,
      "image":
          "https://images.pexels.com/photos/3993449/pexels-photo-3993449.jpeg?auto=compress&cs=tinysrgb&w=800",
      "products": ["کوتاهی مو", "رنگ مو", "آرایش عروس"]
    },
    {
      "id": 5,
      "name": "داروخانه شبانه‌روزی سلامت",
      "category": "داروخانه",
      "address": "چهارراه ولیعصر، جنب بانک ملی",
      "phone": "۰۲۱-۷۷۸۸۹۹۰۰",
      "rating": 4.3,
      "image":
          "https://images.pexels.com/photos/356040/pexels-photo-356040.jpeg?auto=compress&cs=tinysrgb&w=800",
      "products": ["دارو", "مکمل غذایی", "لوازم بهداشتی"]
    },
    {
      "id": 6,
      "name": "قنادی شیرین",
      "category": "قنادی",
      "address": "خیابان کریمخان، نرسیده به چهارراه",
      "phone": "۰۲۱-۴۴۵۵۶۶۷۷",
      "rating": 4.6,
      "image":
          "https://images.pexels.com/photos/1028714/pexels-photo-1028714.jpeg?auto=compress&cs=tinysrgb&w=800",
      "products": ["کیک تولد", "شیرینی", "بستنی"]
    }
  ];

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 3, vsync: this);
    _loadSearchHistory();
    _loadFavorites();
  }

  @override
  void dispose() {
    _tabController.dispose();
    _searchController.dispose();
    super.dispose();
  }

  void _loadSearchHistory() {
    // Mock search history
    setState(() {
      _searchHistory = [
        'رستوران',
        'کافه',
        'گوشی موبایل',
        'آرایشگاه',
        'داروخانه'
      ];
    });
  }

  void _loadFavorites() {
    // Mock favorites
    setState(() {
      _favoriteBusinessIds = {1, 4, 6};
    });
  }

  void _performSearch() {
    if (_searchController.text.trim().isEmpty) return;

    setState(() {
      _isLoading = true;
      _hasSearched = true;
    });

    // Add to search history
    final query = _searchController.text.trim();
    if (!_searchHistory.contains(query)) {
      setState(() {
        _searchHistory.insert(0, query);
        if (_searchHistory.length > 10) {
          _searchHistory = _searchHistory.take(10).toList();
        }
      });
    }

    // Simulate API call delay
    Future.delayed(const Duration(milliseconds: 800), () {
      List<Map<String, dynamic>> results = [];

      if (_isBusinessSearch) {
        // Search by business name or category
        results = _allBusinesses.where((business) {
          final name = (business['name'] as String).toLowerCase();
          final category = (business['category'] as String).toLowerCase();
          final searchQuery = query.toLowerCase();
          return name.contains(searchQuery) || category.contains(searchQuery);
        }).toList();
      } else {
        // Search by product name
        results = _allBusinesses.where((business) {
          final products = (business['products'] as List<String>);
          return products.any(
              (product) => product.toLowerCase().contains(query.toLowerCase()));
        }).toList();
      }

      setState(() {
        _searchResults = results;
        _isLoading = false;
      });
    });
  }

  void _toggleFavorite(int businessId) {
    setState(() {
      if (_favoriteBusinessIds.contains(businessId)) {
        _favoriteBusinessIds.remove(businessId);
      } else {
        _favoriteBusinessIds.add(businessId);
      }
    });
  }

  void _navigateToBusinessDetail(Map<String, dynamic> business) {
    Navigator.pushNamed(
      context,
      '/business-profile-detail-screen',
      arguments: business,
    );
  }

  void _onSearchHistoryTap(String query) {
    _searchController.text = query;
    _performSearch();
  }

  void _clearSearchHistory() {
    setState(() {
      _searchHistory.clear();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        backgroundColor: AppTheme.lightTheme.scaffoldBackgroundColor,
        body: SafeArea(
          child: Column(
            children: [
              // App Header
              Container(
                padding: EdgeInsets.all(4.w),
                decoration: BoxDecoration(
                  color: AppTheme.lightTheme.colorScheme.surface,
                  boxShadow: [
                    BoxShadow(
                      color: AppTheme.lightTheme.colorScheme.shadow,
                      blurRadius: 4,
                      offset: const Offset(0, 2),
                    ),
                  ],
                ),
                child: Row(
                  children: [
                    GestureDetector(
                      onTap: () => Navigator.pop(context),
                      child: Container(
                        padding: EdgeInsets.all(2.w),
                        child: CustomIconWidget(
                          iconName: 'arrow_back',
                          color: AppTheme.lightTheme.colorScheme.onSurface,
                          size: 6.w,
                        ),
                      ),
                    ),
                    const Spacer(),
                    Text(
                      'مارکت نما',
                      style:
                          AppTheme.lightTheme.textTheme.headlineSmall?.copyWith(
                        fontWeight: FontWeight.w700,
                        color: AppTheme.lightTheme.colorScheme.primary,
                      ),
                    ),
                    const Spacer(),
                    SizedBox(width: 10.w), // Balance the back button
                  ],
                ),
              ),

              // Tab Bar
              Container(
                color: AppTheme.lightTheme.colorScheme.surface,
                child: TabBar(
                  controller: _tabController,
                  tabs: [
                    Tab(
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          CustomIconWidget(
                            iconName: 'search',
                            color: _tabController.index == 0
                                ? AppTheme.lightTheme.colorScheme.primary
                                : AppTheme
                                    .lightTheme.colorScheme.onSurfaceVariant,
                            size: 5.w,
                          ),
                          SizedBox(width: 2.w),
                          Text('جستجو'),
                        ],
                      ),
                    ),
                    Tab(
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          CustomIconWidget(
                            iconName: 'favorite',
                            color: _tabController.index == 1
                                ? AppTheme.lightTheme.colorScheme.primary
                                : AppTheme
                                    .lightTheme.colorScheme.onSurfaceVariant,
                            size: 5.w,
                          ),
                          SizedBox(width: 2.w),
                          Text('علاقه‌مندی‌ها'),
                        ],
                      ),
                    ),
                    Tab(
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          CustomIconWidget(
                            iconName: 'person',
                            color: _tabController.index == 2
                                ? AppTheme.lightTheme.colorScheme.primary
                                : AppTheme
                                    .lightTheme.colorScheme.onSurfaceVariant,
                            size: 5.w,
                          ),
                          SizedBox(width: 2.w),
                          Text('پروفایل'),
                        ],
                      ),
                    ),
                  ],
                ),
              ),

              // Tab Bar View
              Expanded(
                child: TabBarView(
                  controller: _tabController,
                  children: [
                    // Search Tab
                    RefreshIndicator(
                      onRefresh: () async {
                        if (_hasSearched) {
                          _performSearch();
                        }
                      },
                      child: Column(
                        children: [
                          // Search Toggle
                          SearchToggleWidget(
                            isBusinessSearch: _isBusinessSearch,
                            onBusinessToggle: () {
                              setState(() {
                                _isBusinessSearch = true;
                                _searchResults.clear();
                                _hasSearched = false;
                              });
                            },
                            onProductToggle: () {
                              setState(() {
                                _isBusinessSearch = false;
                                _searchResults.clear();
                                _hasSearched = false;
                              });
                            },
                          ),

                          // Search Bar
                          SearchBarWidget(
                            controller: _searchController,
                            isBusinessSearch: _isBusinessSearch,
                            onSearch: _performSearch,
                            onChanged: (value) {
                              setState(() {});
                            },
                          ),

                          // Search History
                          if (!_hasSearched && _searchHistory.isNotEmpty)
                            SearchHistoryWidget(
                              searchHistory: _searchHistory,
                              onHistoryTap: _onSearchHistoryTap,
                              onClearHistory: _clearSearchHistory,
                            ),

                          // Search Results
                          Expanded(
                            child: _isLoading
                                ? Center(
                                    child: CircularProgressIndicator(
                                      color: AppTheme
                                          .lightTheme.colorScheme.primary,
                                    ),
                                  )
                                : _hasSearched && _searchResults.isEmpty
                                    ? EmptyStateWidget(
                                        isSearching: true,
                                        isBusinessSearch: _isBusinessSearch,
                                      )
                                    : _hasSearched
                                        ? ListView.builder(
                                            itemCount: _searchResults.length,
                                            itemBuilder: (context, index) {
                                              final business =
                                                  _searchResults[index];
                                              final businessId =
                                                  business['id'] as int;
                                              return BusinessCardWidget(
                                                business: business,
                                                onTap: () =>
                                                    _navigateToBusinessDetail(
                                                        business),
                                                onFavoriteToggle: () =>
                                                    _toggleFavorite(businessId),
                                                isFavorite: _favoriteBusinessIds
                                                    .contains(businessId),
                                              );
                                            },
                                          )
                                        : EmptyStateWidget(
                                            isSearching: false,
                                            isBusinessSearch: _isBusinessSearch,
                                          ),
                          ),
                        ],
                      ),
                    ),

                    // Favorites Tab
                    _favoriteBusinessIds.isEmpty
                        ? Center(
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                CustomIconWidget(
                                  iconName: 'favorite_border',
                                  color: AppTheme
                                      .lightTheme.colorScheme.onSurfaceVariant,
                                  size: 20.w,
                                ),
                                SizedBox(height: 4.h),
                                Text(
                                  'هنوز کسب و کاری را به علاقه‌مندی‌ها اضافه نکرده‌اید',
                                  textAlign: TextAlign.center,
                                  style:
                                      AppTheme.lightTheme.textTheme.titleMedium,
                                ),
                              ],
                            ),
                          )
                        : ListView.builder(
                            itemCount: _favoriteBusinessIds.length,
                            itemBuilder: (context, index) {
                              final businessId =
                                  _favoriteBusinessIds.elementAt(index);
                              final business = _allBusinesses.firstWhere(
                                (b) => b['id'] == businessId,
                              );
                              return BusinessCardWidget(
                                business: business,
                                onTap: () =>
                                    _navigateToBusinessDetail(business),
                                onFavoriteToggle: () =>
                                    _toggleFavorite(businessId),
                                isFavorite: true,
                              );
                            },
                          ),

                    // Profile Tab
                    Center(
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          CustomIconWidget(
                            iconName: 'person',
                            color: AppTheme.lightTheme.colorScheme.primary,
                            size: 20.w,
                          ),
                          SizedBox(height: 4.h),
                          Text(
                            'پروفایل کاربری',
                            style: AppTheme.lightTheme.textTheme.headlineSmall,
                          ),
                          SizedBox(height: 2.h),
                          Text(
                            'این بخش در نسخه‌های آینده اضافه خواهد شد',
                            textAlign: TextAlign.center,
                            style: AppTheme.lightTheme.textTheme.bodyMedium
                                ?.copyWith(
                              color: AppTheme
                                  .lightTheme.colorScheme.onSurfaceVariant,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
        floatingActionButton: _tabController.index == 0
            ? FloatingActionButton(
                onPressed: () {
                  // Map view placeholder
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(
                      content: Text(
                        'نمایش نقشه در نسخه‌های آینده اضافه خواهد شد',
                        textAlign: TextAlign.center,
                        style:
                            AppTheme.lightTheme.snackBarTheme.contentTextStyle,
                      ),
                      backgroundColor:
                          AppTheme.lightTheme.snackBarTheme.backgroundColor,
                      behavior: SnackBarBehavior.floating,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12),
                      ),
                    ),
                  );
                },
                child: CustomIconWidget(
                  iconName: 'map',
                  color: AppTheme
                      .lightTheme.floatingActionButtonTheme.foregroundColor!,
                  size: 6.w,
                ),
              )
            : null,
      ),
    );
  }
}
