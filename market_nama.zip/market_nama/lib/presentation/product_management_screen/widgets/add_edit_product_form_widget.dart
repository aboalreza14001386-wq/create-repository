import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:image_picker/image_picker.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';

class AddEditProductFormWidget extends StatefulWidget {
  final Map<String, dynamic>? product;
  final Function(Map<String, dynamic>) onSave;
  final VoidCallback onCancel;

  const AddEditProductFormWidget({
    Key? key,
    this.product,
    required this.onSave,
    required this.onCancel,
  }) : super(key: key);

  @override
  State<AddEditProductFormWidget> createState() =>
      _AddEditProductFormWidgetState();
}

class _AddEditProductFormWidgetState extends State<AddEditProductFormWidget> {
  final _formKey = GlobalKey<FormState>();
  final _nameController = TextEditingController();
  final _descriptionController = TextEditingController();
  final _priceController = TextEditingController();

  List<String> _selectedImages = [];
  bool _isLoading = false;
  final ImagePicker _imagePicker = ImagePicker();

  @override
  void initState() {
    super.initState();
    if (widget.product != null) {
      _nameController.text = widget.product!['name'] as String;
      _descriptionController.text = widget.product!['description'] as String;
      _priceController.text = (widget.product!['price'] as String)
          .replaceAll('تومان', '')
          .replaceAll(',', '')
          .trim();
      _selectedImages = List<String>.from(widget.product!['images'] as List);
    }
  }

  @override
  void dispose() {
    _nameController.dispose();
    _descriptionController.dispose();
    _priceController.dispose();
    super.dispose();
  }

  Future<void> _pickImages() async {
    try {
      final List<XFile> images = await _imagePicker.pickMultiImage();
      if (images.isNotEmpty) {
        setState(() {
          for (var image in images) {
            if (_selectedImages.length < 5) {
              _selectedImages.add(image.path);
            }
          }
        });
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('خطا در انتخاب تصاویر'),
          backgroundColor: Colors.red,
        ),
      );
    }
  }

  void _removeImage(int index) {
    setState(() {
      _selectedImages.removeAt(index);
    });
  }

  String _formatPrice(String price) {
    if (price.isEmpty) return '';

    // Remove any non-digit characters
    String cleanPrice = price.replaceAll(RegExp(r'[^\d]'), '');
    if (cleanPrice.isEmpty) return '';

    // Add thousand separators
    final formatter = RegExp(r'(\d{1,3})(?=(\d{3})+(?!\d))');
    String formattedPrice =
        cleanPrice.replaceAllMapped(formatter, (Match m) => '${m[1]},');

    return '$formattedPrice تومان';
  }

  void _handleSave() async {
    if (!_formKey.currentState!.validate()) return;
    if (_selectedImages.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('لطفاً حداقل یک تصویر انتخاب کنید'),
          backgroundColor: Colors.red,
        ),
      );
      return;
    }

    setState(() {
      _isLoading = true;
    });

    // Simulate API call delay
    await Future.delayed(const Duration(seconds: 1));

    final productData = {
      'id': widget.product?['id'] ?? DateTime.now().millisecondsSinceEpoch,
      'name': _nameController.text.trim(),
      'description': _descriptionController.text.trim(),
      'price': _formatPrice(_priceController.text),
      'images': _selectedImages,
      'createdAt': widget.product?['createdAt'] ?? DateTime.now(),
      'updatedAt': DateTime.now(),
    };

    setState(() {
      _isLoading = false;
    });

    widget.onSave(productData);
  }

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;

    return Scaffold(
      appBar: AppBar(
        title: Text(
          widget.product != null ? 'ویرایش محصول' : 'افزودن محصول',
          style: Theme.of(context).textTheme.titleLarge,
        ),
        leading: IconButton(
          onPressed: widget.onCancel,
          icon: CustomIconWidget(
            iconName: 'arrow_back',
            color:
                isDark ? AppTheme.textPrimaryDark : AppTheme.textPrimaryLight,
            size: 24,
          ),
        ),
        actions: [
          TextButton(
            onPressed: _isLoading ? null : _handleSave,
            child: _isLoading
                ? SizedBox(
                    width: 20,
                    height: 20,
                    child: CircularProgressIndicator(
                      strokeWidth: 2,
                      valueColor: AlwaysStoppedAnimation<Color>(
                        isDark ? AppTheme.primaryDark : AppTheme.primaryLight,
                      ),
                    ),
                  )
                : Text(
                    'ذخیره',
                    style: TextStyle(
                      color:
                          isDark ? AppTheme.primaryDark : AppTheme.primaryLight,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
          ),
        ],
      ),
      body: Form(
        key: _formKey,
        child: SingleChildScrollView(
          padding: EdgeInsets.all(4.w),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Product Name Field
              Text(
                'نام محصول',
                style: Theme.of(context).textTheme.titleSmall,
              ),
              SizedBox(height: 1.h),
              TextFormField(
                controller: _nameController,
                textDirection: TextDirection.rtl,
                decoration: const InputDecoration(
                  hintText: 'نام محصول را وارد کنید',
                  hintTextDirection: TextDirection.rtl,
                ),
                validator: (value) {
                  if (value == null || value.trim().isEmpty) {
                    return 'نام محصول الزامی است';
                  }
                  return null;
                },
              ),

              SizedBox(height: 3.h),

              // Product Description Field
              Text(
                'توضیحات محصول',
                style: Theme.of(context).textTheme.titleSmall,
              ),
              SizedBox(height: 1.h),
              TextFormField(
                controller: _descriptionController,
                textDirection: TextDirection.rtl,
                maxLines: 4,
                decoration: const InputDecoration(
                  hintText: 'توضیحات محصول را وارد کنید',
                  hintTextDirection: TextDirection.rtl,
                  alignLabelWithHint: true,
                ),
                validator: (value) {
                  if (value == null || value.trim().isEmpty) {
                    return 'توضیحات محصول الزامی است';
                  }
                  return null;
                },
              ),

              SizedBox(height: 3.h),

              // Product Price Field
              Text(
                'قیمت محصول',
                style: Theme.of(context).textTheme.titleSmall,
              ),
              SizedBox(height: 1.h),
              TextFormField(
                controller: _priceController,
                keyboardType: TextInputType.number,
                inputFormatters: [
                  FilteringTextInputFormatter.digitsOnly,
                ],
                decoration: const InputDecoration(
                  hintText: 'قیمت به تومان',
                  suffixText: 'تومان',
                ),
                validator: (value) {
                  if (value == null || value.trim().isEmpty) {
                    return 'قیمت محصول الزامی است';
                  }
                  return null;
                },
              ),

              SizedBox(height: 3.h),

              // Product Images Section
              Text(
                'تصاویر محصول',
                style: Theme.of(context).textTheme.titleSmall,
              ),
              SizedBox(height: 1.h),

              // Image Gallery
              if (_selectedImages.isNotEmpty)
                Container(
                  height: 20.h,
                  margin: EdgeInsets.only(bottom: 2.h),
                  child: ListView.builder(
                    scrollDirection: Axis.horizontal,
                    itemCount: _selectedImages.length,
                    itemBuilder: (context, index) {
                      return Container(
                        width: 30.w,
                        margin: EdgeInsets.only(right: 2.w),
                        child: Stack(
                          children: [
                            ClipRRect(
                              borderRadius: BorderRadius.circular(8),
                              child: CustomImageWidget(
                                imageUrl: _selectedImages[index],
                                width: double.infinity,
                                height: double.infinity,
                                fit: BoxFit.cover,
                              ),
                            ),
                            Positioned(
                              top: 1.w,
                              right: 1.w,
                              child: GestureDetector(
                                onTap: () => _removeImage(index),
                                child: Container(
                                  padding: EdgeInsets.all(1.w),
                                  decoration: BoxDecoration(
                                    color: Colors.red.withValues(alpha: 0.8),
                                    shape: BoxShape.circle,
                                  ),
                                  child: CustomIconWidget(
                                    iconName: 'close',
                                    color: Colors.white,
                                    size: 16,
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                      );
                    },
                  ),
                ),

              // Add Images Button
              InkWell(
                onTap: _selectedImages.length < 5 ? _pickImages : null,
                borderRadius: BorderRadius.circular(12),
                child: Container(
                  width: double.infinity,
                  height: 15.h,
                  decoration: BoxDecoration(
                    border: Border.all(
                      color:
                          isDark ? AppTheme.dividerDark : AppTheme.dividerLight,
                      style: BorderStyle.solid,
                      width: 2,
                    ),
                    borderRadius: BorderRadius.circular(12),
                    color: (_selectedImages.length >= 5)
                        ? (isDark
                            ? AppTheme.textDisabledDark.withValues(alpha: 0.1)
                            : AppTheme.textDisabledLight.withValues(alpha: 0.1))
                        : Colors.transparent,
                  ),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      CustomIconWidget(
                        iconName: 'add_photo_alternate',
                        color: (_selectedImages.length >= 5)
                            ? (isDark
                                ? AppTheme.textDisabledDark
                                : AppTheme.textDisabledLight)
                            : (isDark
                                ? AppTheme.primaryDark
                                : AppTheme.primaryLight),
                        size: 32,
                      ),
                      SizedBox(height: 1.h),
                      Text(
                        _selectedImages.length >= 5
                            ? 'حداکثر ۵ تصویر'
                            : 'افزودن تصاویر (${_selectedImages.length}/5)',
                        style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                              color: (_selectedImages.length >= 5)
                                  ? (isDark
                                      ? AppTheme.textDisabledDark
                                      : AppTheme.textDisabledLight)
                                  : (isDark
                                      ? AppTheme.primaryDark
                                      : AppTheme.primaryLight),
                            ),
                      ),
                    ],
                  ),
                ),
              ),

              SizedBox(height: 4.h),
            ],
          ),
        ),
      ),
    );
  }
}
