import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';

class ProductContextMenuWidget extends StatelessWidget {
  final Map<String, dynamic> product;
  final VoidCallback onEdit;
  final VoidCallback onDuplicate;
  final VoidCallback onDelete;
  final VoidCallback onSetFeatured;
  final VoidCallback onClose;

  const ProductContextMenuWidget({
    Key? key,
    required this.product,
    required this.onEdit,
    required this.onDuplicate,
    required this.onDelete,
    required this.onSetFeatured,
    required this.onClose,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;

    return Material(
      color: Colors.transparent,
      child: GestureDetector(
        onTap: onClose,
        child: Container(
          color: Colors.black.withValues(alpha: 0.5),
          child: Center(
            child: Container(
              margin: EdgeInsets.symmetric(horizontal: 8.w),
              decoration: BoxDecoration(
                color: isDark ? AppTheme.surfaceDark : AppTheme.surfaceLight,
                borderRadius: BorderRadius.circular(16),
                boxShadow: [
                  BoxShadow(
                    color: isDark ? AppTheme.shadowDark : AppTheme.shadowLight,
                    blurRadius: 20,
                    offset: const Offset(0, 10),
                  ),
                ],
              ),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  // Header
                  Container(
                    padding: EdgeInsets.all(4.w),
                    decoration: BoxDecoration(
                      border: Border(
                        bottom: BorderSide(
                          color: isDark
                              ? AppTheme.dividerDark
                              : AppTheme.dividerLight,
                          width: 1,
                        ),
                      ),
                    ),
                    child: Row(
                      children: [
                        ClipRRect(
                          borderRadius: BorderRadius.circular(8),
                          child: (product['images'] as List).isNotEmpty
                              ? CustomImageWidget(
                                  imageUrl:
                                      (product['images'] as List)[0] as String,
                                  width: 12.w,
                                  height: 12.w,
                                  fit: BoxFit.cover,
                                )
                              : Container(
                                  width: 12.w,
                                  height: 12.w,
                                  color: isDark
                                      ? AppTheme.dividerDark
                                      : AppTheme.dividerLight,
                                  child: Center(
                                    child: CustomIconWidget(
                                      iconName: 'image',
                                      color: isDark
                                          ? AppTheme.textSecondaryDark
                                          : AppTheme.textSecondaryLight,
                                      size: 20,
                                    ),
                                  ),
                                ),
                        ),
                        SizedBox(width: 3.w),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                product['name'] as String,
                                style: Theme.of(context).textTheme.titleMedium,
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                              ),
                              SizedBox(height: 0.5.h),
                              Text(
                                product['price'] as String,
                                style: Theme.of(context)
                                    .textTheme
                                    .bodyMedium
                                    ?.copyWith(
                                      color: isDark
                                          ? AppTheme.primaryDark
                                          : AppTheme.primaryLight,
                                    ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),

                  // Menu Options
                  _buildMenuOption(
                    context,
                    icon: 'edit',
                    title: 'ویرایش محصول',
                    onTap: () {
                      onClose();
                      onEdit();
                    },
                  ),

                  _buildMenuOption(
                    context,
                    icon: 'content_copy',
                    title: 'کپی محصول',
                    onTap: () {
                      onClose();
                      onDuplicate();
                    },
                  ),

                  _buildMenuOption(
                    context,
                    icon: 'star',
                    title: product['isFeatured'] == true
                        ? 'حذف از ویژه'
                        : 'تنظیم به عنوان ویژه',
                    onTap: () {
                      onClose();
                      onSetFeatured();
                    },
                  ),

                  _buildMenuOption(
                    context,
                    icon: 'delete',
                    title: 'حذف محصول',
                    isDestructive: true,
                    onTap: () {
                      onClose();
                      onDelete();
                    },
                  ),

                  SizedBox(height: 2.h),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildMenuOption(
    BuildContext context, {
    required String icon,
    required String title,
    required VoidCallback onTap,
    bool isDestructive = false,
  }) {
    final isDark = Theme.of(context).brightness == Brightness.dark;

    return InkWell(
      onTap: onTap,
      child: Container(
        width: double.infinity,
        padding: EdgeInsets.symmetric(
          horizontal: 4.w,
          vertical: 2.h,
        ),
        child: Row(
          children: [
            CustomIconWidget(
              iconName: icon,
              color: isDestructive
                  ? (isDark ? AppTheme.errorDark : AppTheme.errorLight)
                  : (isDark
                      ? AppTheme.textPrimaryDark
                      : AppTheme.textPrimaryLight),
              size: 20,
            ),
            SizedBox(width: 3.w),
            Text(
              title,
              style: Theme.of(context).textTheme.bodyLarge?.copyWith(
                    color: isDestructive
                        ? (isDark ? AppTheme.errorDark : AppTheme.errorLight)
                        : (isDark
                            ? AppTheme.textPrimaryDark
                            : AppTheme.textPrimaryLight),
                  ),
            ),
          ],
        ),
      ),
    );
  }
}
