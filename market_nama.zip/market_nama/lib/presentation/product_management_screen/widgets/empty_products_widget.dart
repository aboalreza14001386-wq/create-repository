import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';

class EmptyProductsWidget extends StatelessWidget {
  final VoidCallback onAddProduct;

  const EmptyProductsWidget({
    Key? key,
    required this.onAddProduct,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;

    return Center(
      child: Padding(
        padding: EdgeInsets.all(8.w),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            // Empty State Illustration
            Container(
              width: 40.w,
              height: 40.w,
              decoration: BoxDecoration(
                color: isDark
                    ? AppTheme.primaryDark.withValues(alpha: 0.1)
                    : AppTheme.primaryLight.withValues(alpha: 0.1),
                shape: BoxShape.circle,
              ),
              child: Center(
                child: CustomIconWidget(
                  iconName: 'inventory_2',
                  color: isDark ? AppTheme.primaryDark : AppTheme.primaryLight,
                  size: 64,
                ),
              ),
            ),

            SizedBox(height: 4.h),

            // Empty State Title
            Text(
              'هنوز محصولی اضافه نکرده‌اید',
              style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                    fontWeight: FontWeight.w600,
                  ),
              textAlign: TextAlign.center,
            ),

            SizedBox(height: 2.h),

            // Empty State Description
            Text(
              'اولین محصول خود را اضافه کنید و فروش خود را شروع کنید',
              style: Theme.of(context).textTheme.bodyLarge?.copyWith(
                    color: isDark
                        ? AppTheme.textSecondaryDark
                        : AppTheme.textSecondaryLight,
                  ),
              textAlign: TextAlign.center,
            ),

            SizedBox(height: 4.h),

            // Add First Product Button
            ElevatedButton.icon(
              onPressed: onAddProduct,
              icon: CustomIconWidget(
                iconName: 'add',
                color:
                    isDark ? AppTheme.onPrimaryDark : AppTheme.onPrimaryLight,
                size: 20,
              ),
              label: Text(
                'اضافه کردن اولین محصول',
                style: TextStyle(
                  color:
                      isDark ? AppTheme.onPrimaryDark : AppTheme.onPrimaryLight,
                  fontWeight: FontWeight.w600,
                ),
              ),
              style: ElevatedButton.styleFrom(
                backgroundColor:
                    isDark ? AppTheme.primaryDark : AppTheme.primaryLight,
                padding: EdgeInsets.symmetric(
                  horizontal: 6.w,
                  vertical: 2.h,
                ),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
