import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:sizer/sizer.dart';

import '../../core/app_export.dart';
import './widgets/add_edit_product_form_widget.dart';
import './widgets/empty_products_widget.dart';
import './widgets/product_card_widget.dart';
import './widgets/product_context_menu_widget.dart';

class ProductManagementScreen extends StatefulWidget {
  const ProductManagementScreen({Key? key}) : super(key: key);

  @override
  State<ProductManagementScreen> createState() =>
      _ProductManagementScreenState();
}

class _ProductManagementScreenState extends State<ProductManagementScreen> {
  final TextEditingController _searchController = TextEditingController();
  List<Map<String, dynamic>> _allProducts = [];
  List<Map<String, dynamic>> _filteredProducts = [];
  bool _isLoading = false;
  Map<String, dynamic>? _selectedProductForMenu;

  @override
  void initState() {
    super.initState();
    _loadMockProducts();
    _searchController.addListener(_filterProducts);
  }

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  void _loadMockProducts() {
    _allProducts = [
      {
        "id": 1,
        "name": "تی‌شرت مردانه کلاسیک",
        "description":
            "تی‌شرت مردانه با کیفیت بالا از جنس پنبه ۱۰۰٪ مناسب برای استفاده روزانه و ورزش",
        "price": "۲۵۰,۰۰۰ تومان",
        "images": [
          "https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?fm=jpg&q=60&w=3000&ixlib=rb-4.0.3",
          "https://images.unsplash.com/photo-1503341504253-dff4815485f1?fm=jpg&q=60&w=3000&ixlib=rb-4.0.3"
        ],
        "isFeatured": true,
        "createdAt": DateTime.now().subtract(const Duration(days: 5)),
        "updatedAt": DateTime.now().subtract(const Duration(days: 2)),
      },
      {
        "id": 2,
        "name": "شلوار جین زنانه",
        "description":
            "شلوار جین زنانه مدرن با طراحی شیک و راحت، مناسب برای استایل کژوال و رسمی",
        "price": "۴۲۰,۰۰۰ تومان",
        "images": [
          "https://images.unsplash.com/photo-1541099649105-f69ad21f3246?fm=jpg&q=60&w=3000&ixlib=rb-4.0.3"
        ],
        "isFeatured": false,
        "createdAt": DateTime.now().subtract(const Duration(days: 3)),
        "updatedAt": DateTime.now().subtract(const Duration(days: 1)),
      },
      {
        "id": 3,
        "name": "کفش ورزشی مردانه",
        "description":
            "کفش ورزشی مردانه با تکنولوژی جدید برای راحتی بیشتر در ورزش و پیاده‌روی",
        "price": "۸۵۰,۰۰۰ تومان",
        "images": [
          "https://images.unsplash.com/photo-1549298916-b41d501d3772?fm=jpg&q=60&w=3000&ixlib=rb-4.0.3",
          "https://images.unsplash.com/photo-1606107557195-0e29a4b5b4aa?fm=jpg&q=60&w=3000&ixlib=rb-4.0.3"
        ],
        "isFeatured": false,
        "createdAt": DateTime.now().subtract(const Duration(days: 7)),
        "updatedAt": DateTime.now().subtract(const Duration(days: 4)),
      },
      {
        "id": 4,
        "name": "کیف دستی زنانه چرمی",
        "description":
            "کیف دستی زنانه از چرم طبیعی با طراحی کلاسیک و مدرن، مناسب برای مهمانی‌ها",
        "price": "۶۸۰,۰۰۰ تومان",
        "images": [
          "https://images.unsplash.com/photo-1553062407-98eeb64c6a62?fm=jpg&q=60&w=3000&ixlib=rb-4.0.3"
        ],
        "isFeatured": true,
        "createdAt": DateTime.now().subtract(const Duration(days: 1)),
        "updatedAt": DateTime.now(),
      },
      {
        "id": 5,
        "name": "ساعت مچی هوشمند",
        "description":
            "ساعت مچی هوشمند با امکانات پیشرفته تناسب اندام، ضربان قلب و اتصال به گوشی",
        "price": "۱,۲۵۰,۰۰۰ تومان",
        "images": [
          "https://images.unsplash.com/photo-1523275335684-37898b6baf30?fm=jpg&q=60&w=3000&ixlib=rb-4.0.3",
          "https://images.unsplash.com/photo-1508685096489-7aacd43bd3b1?fm=jpg&q=60&w=3000&ixlib=rb-4.0.3"
        ],
        "isFeatured": false,
        "createdAt": DateTime.now().subtract(const Duration(days: 10)),
        "updatedAt": DateTime.now().subtract(const Duration(days: 6)),
      },
    ];

    _filteredProducts = List.from(_allProducts);
  }

  void _filterProducts() {
    final query = _searchController.text.toLowerCase().trim();
    setState(() {
      if (query.isEmpty) {
        _filteredProducts = List.from(_allProducts);
      } else {
        _filteredProducts = _allProducts.where((product) {
          final name = (product['name'] as String).toLowerCase();
          final description = (product['description'] as String).toLowerCase();
          return name.contains(query) || description.contains(query);
        }).toList();
      }
    });
  }

  Future<void> _refreshProducts() async {
    setState(() {
      _isLoading = true;
    });

    // Simulate API call
    await Future.delayed(const Duration(seconds: 1));

    setState(() {
      _isLoading = false;
    });

    Fluttertoast.showToast(
      msg: "محصولات به‌روزرسانی شد",
      toastLength: Toast.LENGTH_SHORT,
      gravity: ToastGravity.BOTTOM,
      backgroundColor: Colors.green,
      textColor: Colors.white,
    );
  }

  void _showAddProductForm() {
    Navigator.of(context).push(
      MaterialPageRoute(
        builder: (context) => AddEditProductFormWidget(
          onSave: _handleSaveProduct,
          onCancel: () => Navigator.of(context).pop(),
        ),
        fullscreenDialog: true,
      ),
    );
  }

  void _showEditProductForm(Map<String, dynamic> product) {
    Navigator.of(context).push(
      MaterialPageRoute(
        builder: (context) => AddEditProductFormWidget(
          product: product,
          onSave: _handleSaveProduct,
          onCancel: () => Navigator.of(context).pop(),
        ),
        fullscreenDialog: true,
      ),
    );
  }

  void _handleSaveProduct(Map<String, dynamic> productData) {
    setState(() {
      final existingIndex = _allProducts.indexWhere(
        (p) => p['id'] == productData['id'],
      );

      if (existingIndex != -1) {
        _allProducts[existingIndex] = productData;
        Fluttertoast.showToast(
          msg: "محصول با موفقیت ویرایش شد",
          toastLength: Toast.LENGTH_SHORT,
          gravity: ToastGravity.BOTTOM,
          backgroundColor: Colors.green,
          textColor: Colors.white,
        );
      } else {
        _allProducts.insert(0, productData);
        Fluttertoast.showToast(
          msg: "محصول با موفقیت اضافه شد",
          toastLength: Toast.LENGTH_SHORT,
          gravity: ToastGravity.BOTTOM,
          backgroundColor: Colors.green,
          textColor: Colors.white,
        );
      }

      _filterProducts();
    });

    Navigator.of(context).pop();
  }

  void _showDeleteConfirmation(Map<String, dynamic> product) {
    final isDark = Theme.of(context).brightness == Brightness.dark;

    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('حذف محصول'),
        content: Text(
            'آیا مطمئن هستید که می‌خواهید "${product['name']}" را حذف کنید؟'),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(),
            child: const Text('انصراف'),
          ),
          TextButton(
            onPressed: () {
              Navigator.of(context).pop();
              _deleteProduct(product);
            },
            child: Text(
              'حذف',
              style: TextStyle(
                color: isDark ? AppTheme.errorDark : AppTheme.errorLight,
              ),
            ),
          ),
        ],
      ),
    );
  }

  void _deleteProduct(Map<String, dynamic> product) {
    setState(() {
      _allProducts.removeWhere((p) => p['id'] == product['id']);
      _filterProducts();
    });

    Fluttertoast.showToast(
      msg: "محصول حذف شد",
      toastLength: Toast.LENGTH_SHORT,
      gravity: ToastGravity.BOTTOM,
      backgroundColor: Colors.red,
      textColor: Colors.white,
    );
  }

  void _duplicateProduct(Map<String, dynamic> product) {
    final duplicatedProduct = Map<String, dynamic>.from(product);
    duplicatedProduct['id'] = DateTime.now().millisecondsSinceEpoch;
    duplicatedProduct['name'] = '${product['name']} (کپی)';
    duplicatedProduct['createdAt'] = DateTime.now();
    duplicatedProduct['updatedAt'] = DateTime.now();

    setState(() {
      _allProducts.insert(0, duplicatedProduct);
      _filterProducts();
    });

    Fluttertoast.showToast(
      msg: "محصول کپی شد",
      toastLength: Toast.LENGTH_SHORT,
      gravity: ToastGravity.BOTTOM,
      backgroundColor: Colors.blue,
      textColor: Colors.white,
    );
  }

  void _toggleFeatured(Map<String, dynamic> product) {
    setState(() {
      final index = _allProducts.indexWhere((p) => p['id'] == product['id']);
      if (index != -1) {
        _allProducts[index]['isFeatured'] =
            !(_allProducts[index]['isFeatured'] ?? false);
        _allProducts[index]['updatedAt'] = DateTime.now();
        _filterProducts();
      }
    });

    final isFeatured = product['isFeatured'] ?? false;
    Fluttertoast.showToast(
      msg: isFeatured ? "محصول از ویژه حذف شد" : "محصول به عنوان ویژه تنظیم شد",
      toastLength: Toast.LENGTH_SHORT,
      gravity: ToastGravity.BOTTOM,
      backgroundColor: Colors.orange,
      textColor: Colors.white,
    );
  }

  void _showProductContextMenu(Map<String, dynamic> product) {
    setState(() {
      _selectedProductForMenu = product;
    });

    showDialog(
      context: context,
      barrierDismissible: true,
      builder: (context) => ProductContextMenuWidget(
        product: product,
        onEdit: () => _showEditProductForm(product),
        onDuplicate: () => _duplicateProduct(product),
        onDelete: () => _showDeleteConfirmation(product),
        onSetFeatured: () => _toggleFeatured(product),
        onClose: () {
          Navigator.of(context).pop();
          setState(() {
            _selectedProductForMenu = null;
          });
        },
      ),
    ).then((_) {
      setState(() {
        _selectedProductForMenu = null;
      });
    });
  }

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;

    return Scaffold(
      appBar: AppBar(
        title: Text(
          'مدیریت محصولات (${_filteredProducts.length})',
          style: Theme.of(context).textTheme.titleLarge,
        ),
        leading: IconButton(
          onPressed: () => Navigator.of(context).pop(),
          icon: CustomIconWidget(
            iconName: 'arrow_back',
            color:
                isDark ? AppTheme.textPrimaryDark : AppTheme.textPrimaryLight,
            size: 24,
          ),
        ),
        bottom: PreferredSize(
          preferredSize: Size.fromHeight(8.h),
          child: Padding(
            padding: EdgeInsets.all(4.w),
            child: TextField(
              controller: _searchController,
              textDirection: TextDirection.rtl,
              decoration: InputDecoration(
                hintText: 'جستجو در محصولات...',
                hintTextDirection: TextDirection.rtl,
                prefixIcon: Padding(
                  padding: EdgeInsets.all(3.w),
                  child: CustomIconWidget(
                    iconName: 'search',
                    color: isDark
                        ? AppTheme.textSecondaryDark
                        : AppTheme.textSecondaryLight,
                    size: 20,
                  ),
                ),
                suffixIcon: _searchController.text.isNotEmpty
                    ? IconButton(
                        onPressed: () {
                          _searchController.clear();
                          _filterProducts();
                        },
                        icon: CustomIconWidget(
                          iconName: 'clear',
                          color: isDark
                              ? AppTheme.textSecondaryDark
                              : AppTheme.textSecondaryLight,
                          size: 20,
                        ),
                      )
                    : null,
                contentPadding: EdgeInsets.symmetric(
                  horizontal: 4.w,
                  vertical: 2.h,
                ),
              ),
            ),
          ),
        ),
      ),
      body: _filteredProducts.isEmpty && _searchController.text.isEmpty
          ? EmptyProductsWidget(onAddProduct: _showAddProductForm)
          : _filteredProducts.isEmpty
              ? Center(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      CustomIconWidget(
                        iconName: 'search_off',
                        color: isDark
                            ? AppTheme.textSecondaryDark
                            : AppTheme.textSecondaryLight,
                        size: 64,
                      ),
                      SizedBox(height: 2.h),
                      Text(
                        'محصولی یافت نشد',
                        style: Theme.of(context).textTheme.titleLarge,
                      ),
                      SizedBox(height: 1.h),
                      Text(
                        'کلمه کلیدی دیگری امتحان کنید',
                        style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                              color: isDark
                                  ? AppTheme.textSecondaryDark
                                  : AppTheme.textSecondaryLight,
                            ),
                      ),
                    ],
                  ),
                )
              : RefreshIndicator(
                  onRefresh: _refreshProducts,
                  child: GridView.builder(
                    padding: EdgeInsets.all(4.w),
                    gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                      crossAxisCount: 2,
                      childAspectRatio: 0.75,
                      crossAxisSpacing: 3.w,
                      mainAxisSpacing: 3.w,
                    ),
                    itemCount: _filteredProducts.length,
                    itemBuilder: (context, index) {
                      final product = _filteredProducts[index];
                      return ProductCardWidget(
                        product: product,
                        onEdit: () => _showEditProductForm(product),
                        onDelete: () => _showDeleteConfirmation(product),
                        onLongPress: () => _showProductContextMenu(product),
                      );
                    },
                  ),
                ),
      floatingActionButton: FloatingActionButton(
        onPressed: _showAddProductForm,
        backgroundColor:
            isDark ? AppTheme.secondaryDark : AppTheme.secondaryLight,
        child: CustomIconWidget(
          iconName: 'add',
          color: isDark ? AppTheme.onSecondaryDark : AppTheme.onSecondaryLight,
          size: 24,
        ),
      ),
    );
  }
}
